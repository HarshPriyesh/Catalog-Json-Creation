-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_stg;

CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_stg (
	pyID	string,
	QCRepairFailReasonCodes ARRAY<STRUCT<subscript:STRING,QCRepairFailReasonCodes:struct<
	AppealDate:string,
	AppealAction:string,
	AppealActionDate:string,
	AppealReason:string,
	Details:string,
	FailHousekeeping:string,
	FailPolicy:string,
	FailureType:string,
	Identifier:string,
	IsAppealed:string,
	pxCreateDateTime:string,
	pxCreateOperator:string,
	pxCreateOpName:string,
	pxCreateSystemID:string,
	pxObjClass:string,
	pyExpanded:string,
	pzIndexes:string,
	ReasonCode:string,
	ReasonCodeSubCategory:string
>>>)
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde' WITH SERDEPROPERTIES (
	"pyID"="pyID",
	"QCRepairFailReasonCodes"="QCRepairFailReasonCodes"
)
STORED AS ORC
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/XMLSOURCEPATH/LBG/';

SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';
SET hive.support.concurrency=true;
SET hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
SET hive.exec.dynamic.partition.mode=nostrict;

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes (
	CaseID	string,
	subscript	bigint,
	AppealDate	timestamp,
	AppealAction	string,
	AppealActionDate	timestamp,
	AppealReason	string,
	Details	string,
	FailHousekeeping	string,
	FailPolicy	string,
	FailureType	string,
	Identifier	string,
	IsAppealed	string,
	pxCreateDateTime	timestamp,
	pxCreateOperator	string,
	pxCreateOpName	string,
	pxCreateSystemID	string,
	pxObjClass	string,
	pyExpanded	string,
	pzIndexes	string,
	ReasonCode	string,
	ReasonCodeSubCategory	string,
	bucked_column	string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/OQ/RBB_LBG/oq_qcrepairfailreasoncodes';
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_upd 
AS SELECT E.*,TRAN_DATE FROM 
(SELECT pyID,
	QCF.subscript,
	QCF.QCRepairFailReasonCodes.AppealDate,
	QCF.QCRepairFailReasonCodes.AppealAction,
	QCF.QCRepairFailReasonCodes.AppealActionDate,
	QCF.QCRepairFailReasonCodes.AppealReason,
	QCF.QCRepairFailReasonCodes.Details,
	QCF.QCRepairFailReasonCodes.FailHousekeeping,
	QCF.QCRepairFailReasonCodes.FailPolicy,
	QCF.QCRepairFailReasonCodes.FailureType,
	QCF.QCRepairFailReasonCodes.Identifier,
	QCF.QCRepairFailReasonCodes.IsAppealed,
	QCF.QCRepairFailReasonCodes.pxCreateDateTime,
	QCF.QCRepairFailReasonCodes.pxCreateOperator,
	QCF.QCRepairFailReasonCodes.pxCreateOpName,
	QCF.QCRepairFailReasonCodes.pxCreateSystemID,
	QCF.QCRepairFailReasonCodes.pxObjClass,
	QCF.QCRepairFailReasonCodes.pyExpanded,
	QCF.QCRepairFailReasonCodes.pzIndexes,
	QCF.QCRepairFailReasonCodes.ReasonCode,
	QCF.QCRepairFailReasonCodes.ReasonCodeSubCategory
FROM dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_stg 
LATERAL VIEW EXPLODE(QCRepairFailReasonCodes) exploded as QCF) E 
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes T 
ON (E.pyID = T.CaseID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes 
	WHERE CaseID IN (
	SELECT pyID 
	FROM dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes PARTITION (tran_date)
SELECT
	pyID,
	cast(subscript as bigint),
	timestamp(regexp_replace(AppealDate,'T|Z',' ')),
	AppealAction,
	timestamp(regexp_replace(AppealActionDate,'T|Z',' ')),
	AppealReason,
	Details,
	FailHousekeeping,
	FailPolicy,
	FailureType,
	Identifier,
	IsAppealed,
	timestamp(regexp_replace(pxCreateDateTime,'T|Z',' ')),
	pxCreateOperator,
	pxCreateOpName,
	pxCreateSystemID,
	pxObjClass,
	pyExpanded,
	pzIndexes,
	ReasonCode,
	ReasonCodeSubCategory,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_QCRepairFailReasonCodes_upd;