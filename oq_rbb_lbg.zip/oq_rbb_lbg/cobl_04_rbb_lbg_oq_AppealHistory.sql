-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_AppealHistory_stg;

CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_AppealHistory_stg  (
	pyID	string,
	AppealHistory ARRAY<STRUCT<subscript:STRING,AppealHistory:struct<
	AppealAccessor:string,
	AppealDate:string,
	AppealType:string,
	IsAppealed:string,
	pxObjClass:string
>>>)
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde' WITH SERDEPROPERTIES (
	"pyID"="pyID",
	"AppealHistory"="AppealHistory"
)
STORED AS ORC
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/XMLSOURCEPATH/LBG/';

SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';
SET hive.support.concurrency=true;
SET hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
SET hive.exec.dynamic.partition.mode=nostrict;

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_AppealHistory (
	CaseID string,
	subscript bigint,
	AppealAccessor string,
	AppealDate timestamp,
	AppealType string,
	IsAppealed string,
	pxObjClass string,
	bucked_column string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/OQ/RBB_LBG/oq_appealhistory';
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_AppealHistory_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_AppealHistory_upd 
AS SELECT E.*,TRAN_DATE FROM 
(SELECT pyID,
	AH.subscript,
	AH.AppealHistory.AppealAccessor,
	AH.AppealHistory.AppealDate,
	AH.AppealHistory.AppealType,
	AH.AppealHistory.IsAppealed,
	AH.AppealHistory.pxObjClass
FROM dasd_cobl_acq.rbb_lbg_oq_AppealHistory_stg 
LATERAL VIEW EXPLODE(AppealHistory) exploded as AH) E 
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_AppealHistory T 
ON (E.pyID = T.CaseID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_AppealHistory 
	WHERE CaseID IN (
	SELECT pyID 
	FROM dasd_cobl_acq.rbb_lbg_oq_AppealHistory_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_AppealHistory_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_AppealHistory PARTITION (tran_date)
SELECT
	pyID,
	cast(subscript as bigint),
	AppealAccessor,
	timestamp(regexp_replace(AppealDate,'T|Z',' ')),
	AppealType,
	IsAppealed,
	pxObjClass,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_AppealHistory_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_AppealHistory_upd;