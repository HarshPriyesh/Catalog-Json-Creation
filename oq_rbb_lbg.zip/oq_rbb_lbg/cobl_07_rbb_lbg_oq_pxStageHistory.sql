-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_stg;

CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_stg  (
	pyID	string,
	pxStageHistory ARRAY<STRUCT<subscript:STRING,pxStageHistory:struct<
	pxCompletedBy:string,
	pxCompletedStageTime:string,
	pxEnterStageTime:string,
	pxObjClass:string,
	pxStageID:string,
	pxStageName:string,
	pxStageType:string
>>>)
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde' WITH SERDEPROPERTIES (
	"pyID"="pyID",
	"pxStageHistory"="pxStageHistory"
)
STORED AS ORC
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/XMLSOURCEPATH/LBG/';

SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';
SET hive.support.concurrency=true;
SET hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
SET hive.exec.dynamic.partition.mode=nostrict;

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_pxStageHistory (
	CaseID	string,
	subscript	string,
	pxCompletedBy	string,
	pxCompletedStageTime	timestamp,
	pxEnterStageTime	timestamp,
	pxObjClass	string,
	pxStageID	string,
	pxStageName	string,
	pxStageType	string,
	bucked_column string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/OQ/RBB_LBG/oq_pxstagehistory';
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_upd 
AS SELECT E.*,TRAN_DATE FROM 
(SELECT pyID,
	SH.subscript,
	SH.pxStageHistory.pxCompletedBy,
	SH.pxStageHistory.pxCompletedStageTime,
	SH.pxStageHistory.pxEnterStageTime,
	SH.pxStageHistory.pxObjClass,
	SH.pxStageHistory.pxStageID,
	SH.pxStageHistory.pxStageName,
	SH.pxStageHistory.pxStageType
FROM dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_stg 
LATERAL VIEW EXPLODE(pxStageHistory) exploded as SH) E 
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_pxStageHistory T 
ON (E.pyID = T.CaseID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_pxStageHistory 
	WHERE CaseID IN (
	SELECT pyID 
	FROM dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_pxStageHistory PARTITION (tran_date)
SELECT
	pyID,
	subscript,
	pxCompletedBy,
	timestamp(regexp_replace(pxCompletedStageTime,'T|Z',' ')),
	timestamp(regexp_replace(pxEnterStageTime,'T|Z',' ')),
	pxObjClass,
	pxStageID,
	pxStageName,
	pxStageType,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_pxStageHistory_upd;