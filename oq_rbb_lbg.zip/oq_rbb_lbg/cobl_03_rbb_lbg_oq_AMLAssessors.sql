-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_stg;

CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_stg  (
	pyID	string,
	AMLAssessors ARRAY<STRUCT<subscript:string,
		AMLAssessors:string
>>)
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde' WITH SERDEPROPERTIES (
	"pyID"="pyID",
	"AMLAssessors"="AMLAssessors"
)
STORED AS ORC
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/XMLSOURCEPATH/LBG/';

SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';
SET hive.support.concurrency=true;
SET hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
SET hive.exec.dynamic.partition.mode=nostrict;

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_AMLAssessors (
	CaseID string,
	subscript bigint,
	AMLAssessors string,
	bucked_column string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/OQ/RBB_LBG/oq_amlassessors';
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd 
AS SELECT S.*, T.tran_date FROM 
(SELECT pyID,
	AA.subscript,
	AA.AMLAssessors
FROM dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_stg 
LATERAL VIEW EXPLODE(AMLAssessors) exploded as AA) S
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_AMLAssessors T 
ON (S.pyID = T.CaseID and S.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_AMLAssessors WHERE CaseID IN (
	SELECT pyID 
	FROM dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_AMLAssessors PARTITION (tran_date)
SELECT
	pyID,
	cast(subscript as bigint),
	AMLAssessors,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd;