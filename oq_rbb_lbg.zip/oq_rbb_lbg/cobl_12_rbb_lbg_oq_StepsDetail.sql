-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_StepsDetail_stg;

CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_StepsDetail_stg  (
	pyID	string,
	StepsDetail ARRAY<STRUCT<subscript:STRING,StepsDetail:struct<
		HoursToComplete:string,
		Lenght:string,
		MinutesToComplete:string,
		pxObjClass:string,
		pzIndexes:string,
		StepName:string
>>>)
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde' WITH SERDEPROPERTIES (
	"pyID"="pyID/text()",
	"StepsDetail"="StepsDetail"
)
STORED AS ORC
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/XMLSOURCEPATH/LBG/';

SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';
SET hive.support.concurrency=true;
SET hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
SET hive.exec.dynamic.partition.mode=nostrict;

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_StepsDetail (
	CaseID	string,
	subscript	string,
	HoursToComplete	bigint,
	Lenght	bigint,
	MinutesToComplete	bigint,
	pxObjClass	string,
	pzIndexes	string,
	StepName	string,
	bucked_column	string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/OQ/RBB_LBG/oq_stepsdetail';
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_StepsDetail_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_StepsDetail_upd 
AS SELECT E.*,TRAN_DATE FROM 
(SELECT pyID,
	SD.subscript,
	SD.StepsDetail.HoursToComplete,
	SD.StepsDetail.Lenght,
	SD.StepsDetail.MinutesToComplete,
	SD.StepsDetail.pxObjClass,
	SD.StepsDetail.pzIndexes,
	SD.StepsDetail.StepName
FROM dasd_cobl_acq.rbb_lbg_oq_StepsDetail_stg 
LATERAL VIEW EXPLODE(StepsDetail) exploded as SD) E 
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_StepsDetail T 
ON (E.pyID = T.CaseID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_StepsDetail 
	WHERE CaseID IN (
	SELECT pyID 
	FROM dasd_cobl_acq.rbb_lbg_oq_StepsDetail_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_StepsDetail_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_StepsDetail PARTITION (tran_date)
SELECT
	pyID,
	subscript,
	cast(HoursToComplete as bigint),
	cast(Lenght as bigint),
	cast(MinutesToComplete as bigint),
	pxObjClass,
	pzIndexes,
	StepName,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_StepsDetail_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_StepsDetail_upd;