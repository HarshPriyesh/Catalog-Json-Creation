-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_stg;

CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_stg  (
	pyID	string,
	QCFailReasonCodes ARRAY<STRUCT<subscript:STRING,QCFailReasonCodes:struct<
	AppealDate:string,
	AppealAction:string,
	AppealActionDate:string,
	AppealReason:string,
	Details:string,
	FailHousekeeping:string,
	FailPolicy:string,
	FailureType:string,
	Identifier:string,
	IsAppealed:string,
	pxCreateDateTime:string,
	pxCreateOperator:string,
	pxCreateOpName:string,
	pxCreateSystemID:string,
	pxObjClass:string,
	pyExpanded:string,
	pzIndexes:string,
	ReasonCode:string,
	ReasonCodeSubCategory:string
>>>)
ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.orc.OrcSerde' WITH SERDEPROPERTIES (
	"pyID"="pyID",
	"QCFailReasonCodes"="QCFailReasonCodes"
)
STORED AS ORC
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/XMLSOURCEPATH/LBG/';

SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';
SET hive.support.concurrency=true;
SET hive.txn.manager=org.apache.hadoop.hive.ql.lockmgr.DbTxnManager;
SET hive.exec.dynamic.partition.mode=nostrict;

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes (
	CaseID	string,
	subscript	bigint,
	AppealDate	timestamp,
	AppealAction	string,
	AppealActionDate	timestamp,
	AppealReason	string,
	Details	string,
	FailHousekeeping	string,
	FailPolicy	string,
	FailureType	string,
	Identifier	string,
	IsAppealed	string,
	pxCreateDateTime	timestamp,
	pxCreateOperator	string,
	pxCreateOpName	string,
	pxCreateSystemID	string,
	pxObjClass	string,
	pyExpanded	string,
	pzIndexes	string,
	ReasonCode	string,
	ReasonCodeSubCategory	string,
	bucked_column	string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
LOCATION 'gs://ap-edhsta-bld-01-stb-euwe2-coblstaging-01/OQ/RBB_LBG/oq_qcfailreasoncodes';
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd 
AS SELECT E.*,TRAN_DATE FROM 
(SELECT pyID,
	QCF.subscript,
	QCF.QCFailReasonCodes.AppealDate,
	QCF.QCFailReasonCodes.AppealAction,
	QCF.QCFailReasonCodes.AppealActionDate,
	QCF.QCFailReasonCodes.AppealReason,
	QCF.QCFailReasonCodes.Details,
	QCF.QCFailReasonCodes.FailHousekeeping,
	QCF.QCFailReasonCodes.FailPolicy,
	QCF.QCFailReasonCodes.FailureType,
	QCF.QCFailReasonCodes.Identifier,
	QCF.QCFailReasonCodes.IsAppealed,
	QCF.QCFailReasonCodes.pxCreateDateTime,
	QCF.QCFailReasonCodes.pxCreateOperator,
	QCF.QCFailReasonCodes.pxCreateOpName,
	QCF.QCFailReasonCodes.pxCreateSystemID,
	QCF.QCFailReasonCodes.pxObjClass,
	QCF.QCFailReasonCodes.pyExpanded,
	QCF.QCFailReasonCodes.pzIndexes,
	QCF.QCFailReasonCodes.ReasonCode,
	QCF.QCFailReasonCodes.ReasonCodeSubCategory
FROM dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_stg 
LATERAL VIEW EXPLODE(QCFailReasonCodes) exploded as QCF) E 
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes T 
ON (E.pyID = T.CaseID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes 
	WHERE CaseID IN (
	SELECT pyID 
	FROM dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes PARTITION (tran_date)
SELECT
	pyID,
	cast(subscript as bigint),
	timestamp(regexp_replace(AppealDate,'T|Z',' ')),
	AppealAction,
	timestamp(regexp_replace(AppealActionDate,'T|Z',' ')),
	AppealReason,
	Details,
	FailHousekeeping,
	FailPolicy,
	FailureType,
	Identifier,
	IsAppealed,
	timestamp(regexp_replace(pxCreateDateTime,'T|Z',' ')),
	pxCreateOperator,
	pxCreateOpName,
	pxCreateSystemID,
	pxObjClass,
	pyExpanded,
	pzIndexes,
	ReasonCode,
	ReasonCodeSubCategory,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd;