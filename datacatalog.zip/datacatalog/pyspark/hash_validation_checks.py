#####################################################################################################
# Program Name : hash_validation_checks                                                             #
# Purpose      : pyspark script to Perfoorm the file validations                                    #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Set program variables                                                                             #
#####################################################################################################

#use package org.apache.spark:spark-avro_2.12:2.4.1
#use jars gs://spark-lib/bigquery/spark-bigquery-latest.jar
print("[INFO]:    Pyspark Job to validate Checksum started")
import pyspark
from pyspark.sql import *
from pyspark.context import SparkContext
from pyspark.sql.types import *
from pyspark.sql.functions import *
import os
import sys
import datetime
from google.cloud import storage
storage_client = storage.Client()

# Set the parameters
print("[INFO]:    Set Program Parameters")

print("[INFO]:    The parameter information")
hive_tbl = sys.argv[1]
print("[INFO]:    parameter hive_tbl = %s" %(hive_tbl))
src_cntrl_fl_uri = sys.argv[2]
print("[INFO]:    parameter src_cntrl_fl_uri = %s" %(src_cntrl_fl_uri))
gcp_cntrl_fl_uri = sys.argv[3]
print("[INFO]:    parameter gcp_cntrl_fl_uri = %s" %(gcp_cntrl_fl_uri))
partition_ind = sys.argv[4]
print("[INFO]:    parameter partition_ind = %s" %(partition_ind))
gcp_bq_project = sys.argv[5]
print("[INFO]:    parameter gcp_bq_project = %s" %(gcp_bq_project))
gcp_bq_dataset = sys.argv[6]
print("[INFO]:    parameter gcp_bq_dataset = %s" %(gcp_bq_dataset))
gcp_bq_tbl = sys.argv[7]
print("[INFO]:    parameter gcp_bq_tbl = %s" %(gcp_bq_tbl))
src_frmt = sys.argv[8]
print("[INFO]:    parameter src_frmt = %s" %(src_frmt))
gcp_frmt = sys.argv[9]
print("[INFO]:    parameter gcp_frmt = %s" %(gcp_frmt))
temp_bucket = sys.argv[10]
print("[INFO]:    parameter temp_bucket = %s" %(temp_bucket))

bq_tbl_nm = gcp_bq_project + "." + gcp_bq_dataset + "." + gcp_bq_tbl
print("[INFO]:    parameter bq_tbl_nm = %s" %(bq_tbl_nm))


#if partition_ind == 3 :
#    print("[INFO]:    partition_ind is integer")
#elif partition_ind == 2 :
#    print("[INFO]:    partition_ind is integer")
#elif partition_ind == '2' :
#    print("[INFO]:    partition_ind is string")
#elif partition_ind == '3' :
#    print("[INFO]:    partition_ind is string")

print("[INFO]:    Setup the schema files")
# Setting up the file schema
src_schema = StructType([StructField("File_nm", StringType(), True),
                         StructField("hash_value", StringType(), True)])

gcp_schema = StructType([StructField("File_nm", StringType(), True),
                         StructField("hash_value", StringType(), True)])

# Setup the delimiter value
print("[INFO]:    Setup the file delimiters")
src_delim = ","
gcp_delim = ","

spark = SparkSession.builder\
        .master("yarn")\
        .enableHiveSupport()\
        .config("spark.default.parallelism", "200")\
        .appName("hash_val")\
        .getOrCreate()

sc = SparkContext.getOrCreate()

spark.conf.set('temporaryGcsBucket',temp_bucket)

try:
    # Read the control file from the source

    print("[INFO]:    Reading the source control file %s" %(src_cntrl_fl_uri))					  
    src = spark.read.schema(src_schema) \
               .format("csv") \
               .option("delimiter", src_delim) \
               .load(src_cntrl_fl_uri)

    #src.show(10,False)
    print("[INFO]:    Reading the GCP control file %s" %(gcp_cntrl_fl_uri))    
    gcp = spark.read.schema(gcp_schema) \
               .format("csv") \
               .option("delimiter", gcp_delim) \
               .load(gcp_cntrl_fl_uri)

    #gcp.show(10,False)
    src.createOrReplaceTempView("src")
    gcp.createOrReplaceTempView("gcp")

    print("[INFO]:    Extracting the filename and partition information")       
    if partition_ind == '3' :
        # Read the partition from the filename
        src_df = spark.sql(""" select substring_index(file_nm, '/', -1) as filename,
                                      split(split(substring_index(file_nm, '/', -2), '/')[0], '=')[1] as ingestion_day, 
                                      split(split(substring_index(file_nm, '/', -3), '/')[0], '=')[1] as ingestion_month,
                                      split(split(substring_index(file_nm, '/', -4), '/')[0], '=')[1] as ingestion_year,
                                      hash_value
                               from src """)
    
        gcp_df = spark.sql(""" select substring_index(file_nm, '/', -1) as filename,
                                      split(split(substring_index(file_nm, '/', -2), '/')[0], '=')[1] as ingestion_day, 
                                      split(split(substring_index(file_nm, '/', -3), '/')[0], '=')[1] as ingestion_month,
                                      split(split(substring_index(file_nm, '/', -4), '/')[0], '=')[1] as ingestion_year,
                                      hash_value
                               from gcp """)
    elif partition_ind == '2' :
        # Read the partition from the filename
        src_df = spark.sql(""" select substring_index(file_nm, '/', -1) as filename,
                                      0 as ingestion_day,
                                      split(split(substring_index(file_nm, '/', -2), '/')[0], '=')[1] as ingestion_month,
                                      split(split(substring_index(file_nm, '/', -3), '/')[0], '=')[1] as ingestion_year,
                                      hash_value
                                from src """)

        gcp_df = spark.sql(""" select substring_index(file_nm, '/', -1) as filename,
                                      0 as ingestion_day,
                                      split(split(substring_index(file_nm, '/', -2), '/')[0], '=')[1] as ingestion_month,
                                      split(split(substring_index(file_nm, '/', -3), '/')[0], '=')[1] as ingestion_year,
                                      hash_value
                                from gcp """)
    elif partition_ind == '1' :
        # Read the partition from the filename
        src_df = spark.sql(""" select substring_index(file_nm, '/', -1) as filename,
                                      0 as ingestion_day,
                                      0 as ingestion_month,
                                      split(split(substring_index(file_nm, '/', -2), '/')[0], '=')[1] as ingestion_year,
                                      hash_value
                                from src """)

        gcp_df = spark.sql(""" select substring_index(file_nm, '/', -1) as filename,
                                      0 as ingestion_day,
                                      0 as ingestion_month
                                      split(split(substring_index(file_nm, '/', -2), '/')[0], '=')[1] as ingestion_year,
                                      hash_value
                                from gcp """)
    elif partition_ind == '0' :
        src_df = spark.sql(""" select substring_index(file_nm, '/', -1) as filename,
                                      hash_value
                               from src """)
    
        gcp_df = spark.sql(""" select substring_index(file_nm, '/', -1) as filename,
                                      hash_value
                               from gcp """)
    else :
        print("[INFO]:    Too many partitions")
        raise Exception('Too Many partitions')

    src_df.createOrReplaceTempView("src_df")
    gcp_df.createOrReplaceTempView("gcp_df")

    print("[INFO]:    Create the BQ entry to compare the checksum")       
    if int(partition_ind) > 0 :
	    bq_df = spark.sql(""" select '01' as rec_type,
                                     '%s' as tbl_nm,
                                     unix_timestamp(current_timestamp()) * 1000000 as gcp_ld_ts,
                                     cast(a.ingestion_year as integer) as ingestion_year,
                                     cast(a.ingestion_month as integer) as ingestion_month,
                                     cast(a.ingestion_day as integer) as ingestion_day,
                                     a.filename as file_nm,
                                     cast(null as integer) as cntrl_fl_cnt,
        							 cast(null as integer) as gcp_cnt,
                                     a.hash_value as cntrl_fl_hash_key,
                                     b.hash_value as gcp_hash_key,
                                     cast(null as string) as cnt_match_ind,
                                     /* Changes done to forcefully match the hash value, need to be removed once the issue is fixed */
                                     case when a.hash_value = b.hash_value 
                                             then 'Y'
                                          else 'N'
                                     end as hashkey_match_ind, 
                                     /*'Y' as hashkey_match_ind, */
                                     '%s' as src_frmt,
                                     '%s' as gcp_frmt,
                                     cast(null as integer) as gcp_rfrmt_cnt,
                                     cast(null as string) as rfrmt_cnt_match_ind
                              from src_df a
                              left outer join gcp_df b
                              on a.filename = b.filename and 
                                 a.ingestion_year = b.ingestion_year and 
                                 a.ingestion_month = b.ingestion_month and 
                                 a.ingestion_day = b.ingestion_day """ %(hive_tbl, src_frmt, gcp_frmt))
    else :
        bq_df = spark.sql(""" select '01' as rec_type,
                                     '%s' as tbl_nm,
                                     unix_timestamp(current_timestamp()) * 1000000 as gcp_ld_ts,
                                     0 as ingestion_year,
                                     0 as ingestion_month,
                                     0 as ingestion_day,
                                     a.filename as file_nm,
                                     cast(null as integer) as cntrl_fl_cnt,
        							 cast(null as integer) as gcp_cnt,
                                     a.hash_value as cntrl_fl_hash_key,
                                     b.hash_value as gcp_hash_key,
                                     cast(null as string) as cnt_match_ind,
                                     /* Changes done to forcefully match the hash value, need to be removed once the issue is fixed */
                                     case when a.hash_value = b.hash_value 
                                             then 'Y'
                                          else 'N'
                                     end as hashkey_match_ind, 
                                     /*'Y' as hashkey_match_ind, */
                                     '%s' as src_frmt,
                                     '%s' as gcp_frmt,
                                     cast(null as integer) as gcp_rfrmt_cnt,
                                     cast(null as string) as rfrmt_cnt_match_ind
                              from src_df a
                              left outer join gcp_df b
                              on a.filename = b.filename """ %(hive_tbl, src_frmt, gcp_frmt))

    print("[INFO]:    Check count of failed Validations")       
    fail_cnt = bq_df.filter(col("hashkey_match_ind") == 'N').count()

    print("[INFO]:    Write the checksum validation results to BQ")           
    #bq_df.write.format('bigquery') \
    #           .option('table', bq_tbl_nm) \
    #           .mode("Append") \
    #           .save()

    bq_df.write.format('bigquery') \
               .option('table', bq_tbl_nm) \
               .option("writeMethod", "direct") \
               .mode("Append") \
               .save()
    
    #bq_df.printSchema()
    #bq_df.show(10, False)

    print("[INFO]:    Raise exception if the validation fails")          
    if fail_cnt > 0 :
        raise Exception('Hashkey Validation failed for %s files' %(fail_cnt))
        print('Hashkey Validation failed for %s files' %(fail_cnt))

except Exception as e:
    print("[ERROR]:       %s" %(e))
    sys.exit(1)

finally:
    sc.stop()
    spark.stop()

