#!/bin/bash
ENV=$1
CONFIG_STAGING_BUCKET=$2

# Copy the jars and files to copy
echo "gsutil -m cp /app/python/*  gs://${CONFIG_STAGING_BUCKET}/engine/data_catalog_module/python/"

gsutil -m cp /app/python/*  gs://${CONFIG_STAGING_BUCKET}/engine/data_catalog_module/python/

echo "gsutil -m cp /app/config/${ENV}/*  gs://${CONFIG_STAGING_BUCKET}/engine/data_catalog_module/config/"
gsutil -m cp /app/config/${ENV}/*  gs://${CONFIG_STAGING_BUCKET}/engine/data_catalog_module/config/

echo "gsutil -m cp -r /app/schema/* gs://${CONFIG_STAGING_BUCKET}/engine/data_catalog_module/"
gsutil -m cp -r /app/schema/* gs://${CONFIG_STAGING_BUCKET}/engine/data_catalog_module/