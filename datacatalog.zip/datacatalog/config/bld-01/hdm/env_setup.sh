#####################################################################################################
# Program Name : env_setup                                                                          #
# Purpose      : Script to set env variables and functions                                          #
# Author       :                                                                                    #
#####################################################################################################

# The GCP project where the BQ dataset exists
export stg_gcp_project="ap-edhins-bld-01-2c23"
export con_gcp_project="ap-edhcon-bld-01-f678"
export pro_gcp_project="ap-edhpro-bld-01-446a"

# The BQ Dataset name
export stg_bq_dataset="ap_edhins_bld_01_bqd_euwe2_recon_01"
export con_bq_dataset="recon_dataset"

# The Bigquery Table to load
export stg_bq_tbl="history_load"
export con_bq_tbl="hist_data_recon"

export temp_bucket_pro="ap-edh-bld-01-stb-euwe2-processing-01"

# The control file
#export hdm_config="config_file_extractor.txt"

#export schema_bucket="gs://boxwood-complex-schema/"

export staging_bucket="gs://ap-edh-bld-01-stb-euwe2-processing-01/hdm_staging"

#export dataproc_cluster="ap-edhpro-bld-01-dcl-euwe2-test"

export prefix="HISTORY_"

err_msg() {
           echo "[ERROR]:        ${1}"
           echo "[INFO]:         Stopping execution of ${2}"
           #exit ${3}
          }

msg() {
       echo "[INFO]:         ${1}"
      }

export -f msg
export -f err_msg
