#####################################################################################################
# Program Name : gcs_file_converter                                                                 #
# Purpose      : Script to convert the files                                                          #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Set program variables                                                                             #
#####################################################################################################

SCRIPT_NM=$(basename $0)
src_uri=${1}
src_frmt=${2}
tgt_frmt=${3}
target_uri=${4}
cluster_nm=${5}
cluster_region=${6}
schema_file=${7}
partition_ind=${8}

#####################################################################################################
# Submit a Pyspark Job to the cluster                                                               #
#####################################################################################################

msg "Submiting the pyspark job to cluster ${cluster_nm}"

#gcloud dataproc jobs submit pyspark ${PWD}/file_covert.py \
#--cluster ${cluster_nm} \
#--region ${clstr_region} \
#--properties spark.jars.packages='org.apache.spark:spark-avro_2.12:2.4.1' \
#-- ${src_uri} ${src_frmt} ${tgt_frmt} ${target_uri} ${schema_file}
#spark.jars.packages=org.apache.spark:spark-avro_2.12:2.4.1
#spark-submit --master yarn --deploy-mode cluster ${PWD}/file_covert.py ${src_uri} ${src_frmt} ${tgt_frmt} ${target_uri} ${schema_file} ${partition_ind}
#--properties="spark.dynamicAllocation.enabled=false,spark.shuffle.service.enabled=false,spark.executor.cores=5,spark.executor.memory=12000m,spark.executor.memoryOverhead=2048" \

gcloud dataproc jobs submit pyspark ${PWD}/file_covert.py \
--labels="job_name=file_covert","application=history_data","layer=staging-historic-load" \
--cluster=${cluster_nm} \
--region=${cluster_region} \
--jars /usr/lib/spark/external/spark-avro_2.12-3.1.2.jar \
-- ${src_uri} ${src_frmt} ${tgt_frmt} ${target_uri} ${schema_file} ${partition_ind}

py_err=$?

if [[ ${py_err} -ne 0 ]]
then
   err_msg "Pyspark Job exited with error ${py_err}" "${script_name}" "${py_err}"
   exit ${py_err}
fi
