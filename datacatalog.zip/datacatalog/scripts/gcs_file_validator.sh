#####################################################################################################
# Program Name : gcs_file_validator                                                                 #
# Purpose      : Script to get checksum and count of the files                                      #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Set program variables                                                                             #
#####################################################################################################

script_name=${0}
file_uri=${1}
folder=${2}
frmt=${3}
gcp_project=${4}
gcp_datset=${5}
cntrl_fl=${6}
file_val="P"


echo "[INFO]:             Creating a subfolder in local directory ${PWD}/${folder}"
mkdir -p ${PWD}/${folder}

echo "[INFO]:             Remove older entries from the folder ${PWD}/${folder}"
rm -rf ${PWD}/${folder}/*

while read file_nm
do
    file_name=$(echo ${file_nm} | awk -F "/" '{print $NF}' | awk -F "." '{print $(NF-1)}')
    file_nm_ext=$(echo ${file_nm} | awk -F "/" '{print $NF}')

    echo "[INFO]:             Processing file ${file_name}"
    echo "[INFO]:             Calculate HASH value of the files ${file_name}"

    while IFS=':' read -r key value
    do
        case $(echo ${key}) in
            "Hash (md5)") md5_checksum=$(echo $value);;
            "Hash (crc32c)") crc_checksum=$(echo $value);;
        esac
    done <<< $(gsutil hash -h ${file_nm})

    #####################################################################################################
    # Create an external table for the file                                                             #
    #####################################################################################################

    echo "[INFO]:             Creating an external table to calculate the file count"

    create_sql="create or replace external table ${gcp_project}.${gcp_datset}.ext_${file_name} options (format = '${frmt}', uris = ['${file_nm}'])"

    echo "[INFO]:             Executing ${create_sql}"

    bq query --use_legacy_sql=false ${create_sql}

    #####################################################################################################
    # Get count of file                                                                                 #
    #####################################################################################################

    echo "[INFO]:             Retrieving the counts"

    cnt_sql="select count(1) from ${gcp_project}.${gcp_datset}.ext_${file_name}"

    echo "[INFO]:             Executing ${cnt_sql}"

    cnt=$(echo $(bq query --use_legacy_sql=false ${cnt_sql} 2> /dev/null)| cut -d "|" -f 4 | sed 's/^ *//g')

    #####################################################################################################
    # Drop the table                                                                                    #
    #####################################################################################################

    echo "[INFO]:             Drop the external table"

    drop_sql="drop table ${gcp_project}.${gcp_datset}.ext_${file_name}"

    echo "[INFO]:             Executing ${drop_sql}"

    bq query --use_legacy_sql=false ${drop_sql}

    echo "[INFO]:             Get the SRC file stats from ${cntrl_fl}"

    while IFS=',' read -r src_fl_nm src_cnt src_crc2 src_md5
    do
        if [[ ${src_fl_nm} == ${file_nm_ext} ]]
        then
            break
        fi
    done <<< $(gsutil cat ${cntrl_fl})

    if [[ ${src_cnt} -ne ${cnt} ]]
    then
        cnt_val="Fail"
        file_val="F"
    else
        cnt_val="Pass"
    fi

    if [[ ${src_crc2} != ${crc_checksum} ]]
    then
        hash_val="Fail"
        file_val="F"
    else
        hash_val="Pass"
    fi

    #if [[ ${src_md5} != ${md5_checksum} ]]
    #then
    #    hash_val="Fail"
    #else
    #    hash_val="Pass"
    #fi

    echo "[INFO]:             Store the file stats locally"

    echo "${file_name},${file_name},${file_nm_ext},${cnt},${crc_checksum},${src_cnt},${src_crc2},${cnt_val},${hash_val}" > ${PWD}/${folder}/${file_name}.txt

done <<< $(gsutil ls -r ${file_uri}* | grep "\.${frmt}")

echo "[INFO]:             Collate the stats file to load into BQ"

cat ${PWD}/${folder}/*.txt > ${PWD}/${folder}/file_stats_upload.csv

if [[ $? -ne 0 ]]
then
    "[ERROR]:        File consolidation failed..."
    "[INFO]:         Script ${SCRIPT_NM} Terminated"
    exit 1
else
    bq load -F "," ${gcp_project}:${bq_dataset}.${bq_tbl} ${PWD}/${folder}/file_stats_upload.csv

    if [[ $? -ne 0 ]]
    then
        echo "[ERROR]:        Loading the file stats to BQ table failed"
        echo "[INFO]:         Script ${SCRIPT_NM} Terminated"
        exit 2
    else
        echo "[INFO]:        Loading the file stats to BQ table Completed sucessfully"
        rm -r ${PWD}/${folder}
    fi
fi


if [[ ${file_val} == "F" ]]
then
    echo "[ERROR]:        Validations failed for the files in URI ${file_uri}"
    echo "[INFO]:         Stopping execution of ${SCRIPT_NM}"
    exit 4
else
    echo "[ERROR]:        Validations completed for files in URI ${file_uri}"
fi
