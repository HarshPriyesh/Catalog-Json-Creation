#####################################################################################################
# Program Name : ad_hoc_cleanup                                                                     #
# Purpose      : Script to perform ad-hoc cleanup with hardcoded values                             #
# Author       :                                                                                    #
#####################################################################################################


SCRIPT_NM=$(basename $0)

echo "Removing files from staging Directory"
gsutil -m rm -r gs://ap-edhsta-prd-01-stb-euwe2-cbsstaging-01/CBS_AL00473/TED01/TED01_1/ingestion_year=2021
gsutil -m rm -r gs://ap-edhsta-prd-01-stb-euwe2-cbsstaging-01/CBS_AL00473/TED01/TED01_1/ingestion_year=2022/ingestion_month=1
gsutil -m rm -r gs://ap-edhsta-prd-01-stb-euwe2-cbsstaging-01/CBS_AL00473/TED01/TED01_1/ingestion_year=2022/ingestion_month=2
gsutil -m rm -r gs://ap-edhsta-prd-01-stb-euwe2-cbsstaging-01/CBS_AL00473/TED01/TED01_1/ingestion_year=2022/ingestion_month=3
gsutil -m rm -r gs://ap-edhsta-prd-01-stb-euwe2-cbsstaging-01/CBS_AL00473/TED01/TED01_1/ingestion_year=2022/ingestion_month=4
gsutil -m rm -r gs://ap-edhsta-prd-01-stb-euwe2-cbsstaging-01/CBS_AL00473/TED01/TED01_1/ingestion_year=2022/ingestion_month=6
gsutil -m rm -r gs://ap-edhsta-prd-01-stb-euwe2-cbsstaging-01/CBS_AL00473/TED01/TED01_1/ingestion_year=2022/ingestion_month=7
gsutil -m rm -r gs://ap-edhsta-prd-01-stb-euwe2-cbsstaging-01/CBS_AL00473/TED01/TED01_1/ingestion_year=2022/ingestion_month=8

echo "Staging location cleaned, check logs for any failures"

echo "Copying the files from landing"

gsutil -m cp -r gs://ap-edhlnd-prd-01-stb-euwe2-historic-01/history/HISTORY_CBS_ted01_1_* gs://ap-edhlnd-prd-01-stb-euwe2-historic-01/archive/CBS/TED01_1/

if [[ $? -ne 0 ]]
then
    echo "Failed to archive files from landing location"
    exit 1
else
    gsutil -m rm -r gs://ap-edhlnd-prd-01-stb-euwe2-historic-01/history/HISTORY_CBS_ted01_1_* 
    if [[ $? -ne 0 ]]
    then
        echo "Failed to remove files from landing location"
    else
        echo "Removed files from landing location"
    fi
fi

