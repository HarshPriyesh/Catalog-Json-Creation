#####################################################################################################
# Program Name : data_catalog_create_tags                                                           #
# Purpose      : The script reads a list of tag_tempalte names and fields to creates them           #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Import required modules                                                                           #
#####################################################################################################

import json
import os
import sys
import data_catalog_operations as dco

#p_args = json.loads(sys.argv[1])

#gcp_project = p_args["project_id"]
#gcp_location = p_args["location"]
#param_file = p_args["param_file"]

gcp_project = sys.argv[1]
gcp_location = sys.argv[2]
#config_file = sys.argv[3]
#
#if len(config_file) != 0:
#    if dco.valid_config(config_file):
#        param_file = "data_catalog_" + config_file + "_config.txt"
#        paramfile = open(param_file, 'r')
#    else:
#        print("Param file name is invalid: %s" %(config_file))
#        sys.exit(1)
#else:
#    print("Param file value incorrect")
#    sys.exit(1)
    
paramfile = open("data_catalog_manage_tag_template_config.txt", 'r')

lines = paramfile.readlines()

for i in lines[1:]:
    params = i.split(',')
    tag_template_id = params[0].strip()
    template_display_name = params[1].strip()
    tag_field_name = params[2].strip()
    tag_field_display_name = params[3].strip()
    operation = params[4].strip()
    
    print("List the tag_template details if available %s" %(tag_template_id))
    args = '{"project_id": "%s", "location": "%s", "tag_template_id": "%s"}' %(gcp_project,gcp_location,tag_template_id)
    tag_template = dco.get_tag_template(args)
    print("Tag Templates available: %s" %(tag_template))
    
    if not bool(tag_template):
        if operation == "create":
            args = '{"project_id": "%s", "location": "%s", "display_name": "%s", "field": [{"field_name":"%s", "field_display_name": "%s"}], "tag_template_id": "%s"}' %(gcp_project,gcp_location,template_display_name,tag_field_name,tag_field_display_name,tag_template_id)
            dco.create_tag_template(args)
        else :
            print("ERROR:       Tag Template does not exists")
            
    elif not any(d == tag_field_name for d in tag_template["fields"]):
        parent = tag_template["name"]
        if operation == "create":
            args = '{"project_id": "%s", "location": "%s", "parent": "%s", "field_name":"%s", "field_display_name": "%s"}' %(gcp_project,gcp_location,parent,tag_field_name,tag_field_display_name)
            tag_temp_field = dco.add_tag_template_field(args)
            print("INFO:       Tag field added %s" %(tag_temp_field["name"]))
        elif operation == "delete_template":
            args = '{"parent": "%s"}' %(parent)
            dco.delete_tag_template(args)
            print("ERROR:       Tag Template %s Deleted" %(tag_template_id))
        else:
            print("ERROR:       Tag Template %s does not contains the field %s" %(tag_template_id, tag_field_name))
    else:
        if operation == "delete_field":
            num_fields = len(tag_template["fields"])
            if num_fields == 1 :
                print("ERROR:       Tag Template %s contains only 1 field, cannot delete the field" %(tag_template_id))
            else:
                args = '{"parent": "%s"}' %(tag_template["fields"][tag_field_name]["name"])
                dco.delete_tag_template_field(args)
                print("INFO:       Deleted the field %s from Tag Template %s" %(tag_template_id, tag_field_name))
        else:
            print("ERROR:       Tag Template and field already exists")
    
