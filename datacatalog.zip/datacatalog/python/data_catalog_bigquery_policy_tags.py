#####################################################################################################
# Program Name : data_catalog_bigquery_policy_tags                                                  #
# Purpose      : The script reads a list of Bigquery tables, columns, Taxonomies and Policy Tag     #
#                and attaches the tags to the columns                                               #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Import required modules                                                                           #
#####################################################################################################

import json
import os
import sys
import data_catalog_operations as dco

#p_args = json.loads(sys.argv[1])

#gcp_project = p_args["project_id"]
#gcp_location = p_args["location"]
#param_file = p_args["param_file"]

gcp_project = sys.argv[1]
gcp_location = sys.argv[2]
#config_file = sys.argv[3]


args = '{"project_id": "%s", "location": "%s"}' %(gcp_project,gcp_location)
project_taxonomies = dco.list_taxonomies(args)

#if len(config_file) != 0:
#    if dco.valid_config(config_file):
#        param_file = "data_catalog_" + config_file + "_config.txt"
#        paramfile = open(param_file, 'r')
#    else:
#        print("Param file name is invalid: %s" %(config_file))
#        sys.exit(1)
#else:
#    print("Param file value incorrect")
#    sys.exit(1)

paramfile = open("data_catalog_tag_bigquery_col_config.txt", 'r')

lines = paramfile.readlines()

for i in lines[1:]:
    bq_table_id = i.split(',')[0].strip().split(".")
    tag_info = i.split(',')[1].strip()
    bq_tags = tag_info.split(';')
    bq_col_tags = "["
    for tags in bq_tags:
        taxonomy_name = tags.split(':')[0].strip()
        policy_tag_name = tags.split(':')[1].strip()
        bq_column = tags.split(':')[2].strip()
        operation = tags.split(':')[3].strip()
        taxonomy_id = [d["name"] for d in project_taxonomies["taxonomies"] if d["displayName"] == taxonomy_name]
        if not bool(taxonomy_id):
            print(f"Taxonomy {taxonomy_name} does not exists in project {gcp_project} location {gcp_location}")
            continue
    
        args = '{"parent": "%s"}' %(taxonomy_id[0])
        policy_tags_list = dco.list_policy_tags(args)
        policy_tag_id = [d["name"] for d in policy_tags_list["policyTags"] if d["displayName"] == policy_tag_name]
        if not bool(policy_tag_id):
            print(f"Policy tag {policy_tag_name} does not exist in the Taxonomy {taxonomy_name}")
            continue
        
        if len(bq_col_tags) > 1 :
            bq_col_tags = bq_col_tags + ","
        
        col_tags = '{"t_column": "%s", "tag_id": "%s", "operation": "%s"}' %(bq_column,policy_tag_id[0],operation)
        bq_col_tags = bq_col_tags + col_tags
        
    bq_col_tags = bq_col_tags + "]"
        
    
    args = '{"project_id": "%s", "dataset_id": "%s", "table_id": "%s", "tags": %s}' %(bq_table_id[0],bq_table_id[1],bq_table_id[2],bq_col_tags)
    bq_tag = dco.tag_bq_tbl(args)
    print("Tag on BigQuery Table %s" %(bq_table_id))
    for i in bq_tag["schema"]["fields"]:
        if i.get("policyTags") == None :
            print(i)
