#####################################################################################################
# Program Name : data_catalogs_policy_tags                                                          #
# Purpose      : The script reads a list of Taxonomies and Policy Tag and creates them              #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Import required modules                                                                           #
#####################################################################################################

import json
import os
import sys
import data_catalog_operations as dco

#p_args = json.loads(sys.argv[1])

#p_args={"project_id":sys.argv[1], "location": sys.argv[2], "param_file": sys.argv[3]}

#gcp_project = p_args["project_id"]
#gcp_location = p_args["location"]
#param_file = p_args["param_file"]

gcp_project = sys.argv[1]
gcp_location = sys.argv[2]
#config_file = sys.argv[3]
#
#if len(config_file) != 0:
#    if dco.valid_config(config_file):
#        param_file = "data_catalog_" + config_file + "_config.txt"
#        paramfile = open(param_file, 'r')
#    else:
#        print("Param file name is invalid: %s" %(config_file))
#        sys.exit(1)
#else:
#    print("Param file value incorrect")
#    sys.exit(1)
    
paramfile = open("data_catalog_manage_policy_tags_config.txt", 'r')

lines = paramfile.readlines()

for i in lines[1:]:
    params = i.split(',')
    taxonomy_name = params[0].strip()
    polictag = params[1].strip()
    member = params[2].strip()
    role = params[3].strip()
    operation = params[4].strip()
    
    args = '{"project_id": "%s", "location": "%s"}' %(gcp_project,gcp_location)
    project_taxonomies = dco.list_taxonomies(args)
    
    print("Listed Taxonomies: %s" %(project_taxonomies))
    
    if not bool(project_taxonomies) or not any(d["displayName"] == taxonomy_name for d in project_taxonomies["taxonomies"]):
        if operation.lower() == "create":
            print(f"Taxonomy {taxonomy_name} does not exists, creating....")
            activated_policy_types = "FINE_GRAINED_ACCESS_CONTROL"
            args = '{"project_id": "%s", "location": "%s", "display_name": "%s", "activatedPolicyTypes": "%s", "description": ""}' %(gcp_project,gcp_location,taxonomy_name,activated_policy_types)
            taxonomy_det = dco.create_taxonomy(args)
            taxonomy_id = taxonomy_det["name"]
            print(f"[INFO]:    Taxonomy {taxonomy_id} created")
        else:
            print(f"[INFO]:    Taxonomy {taxonomy_name} Does not exist")
            continue
    else:
        taxonomy_id = [d["name"] for d in project_taxonomies["taxonomies"] if d["displayName"] == taxonomy_name][0]
        print(f"[INFO]:    Taxonomy {taxonomy_name} exists")
        print(taxonomy_id)
    
    args = '{"parent": "%s"}' %(taxonomy_id)
    if operation.lower() == "delete_taxonomy" :
        print(f"[INFO]:    Deleting the Taxonomy {taxonomy_name}")
        dco.delete_taxonomy(args)
        continue
    else :
        print(f"[INFO]:    List policy tags in Taxonomy {taxonomy_name}")
        policy_tags_list = dco.list_policy_tags(args)
    
    if not bool(policy_tags_list) or not any(d["displayName"] == polictag for d in policy_tags_list["policyTags"]):
        if operation.lower() == "create" :
            print(f"Policy Tag {polictag} does not exists in Taxonomy {taxonomy_name} creating....")
            args = '{"parent": "%s", "display_name": "%s", "description": "", "parentPolicyTag": ""}' %(taxonomy_id,polictag)
            policy_tag = dco.create_policy_tags(args)
            policy_tag_id = policy_tag["name"]
            print(f"[INFO]:    Policy Tag {policy_tag_id} created")
        elif operation.lower() == "delete" :
            print(f"[INFO]:    Policy Tag {polictag} Does not exist in Taxonomy {taxonomy_name}")
            continue
    else:
        policy_tag_id = [d["name"] for d in policy_tags_list["policyTags"] if d["displayName"] == polictag][0]
        if operation.lower() == "create" :
            print(f"Policy Tag {polictag} already exists in Taxonomy {taxonomy_name}")
            print(policy_tag_id)
        elif operation.lower() == "delete" :
            args = '{"parent": "%s"}' %(policy_tag_id)
            dco.delete_policy_tag(args)
    
    if member != "" and role != "" and operation.lower() != "delete" and operation.lower() != "delete_taxonomy":
        print(f"[INFO]:    Assigning the {role} to {member}")
        args = '{"parent": "%s", "member": "%s", "role": "%s"}' %(policy_tag_id, member, role)
        set_iam = dco.setIam_polict_tags(args)
        print(set_iam)
