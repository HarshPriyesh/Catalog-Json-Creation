#####################################################################################################
# Program Name : data_catalog_create_ext_entries                                                    #
# Purpose      : The script reads a list of Bigquery tables, columns, Taxonomies and Policy Tag     #
#                and attaches the tags to the columns                                               #
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Import required modules                                                                           #
#####################################################################################################

import json
import os
import sys
import data_catalog_operations as dco

#p_args = json.loads(sys.argv[1])

#gcp_project = p_args["project_id"]
#gcp_location = p_args["location"]
#param_file = p_args["param_file"]

gcp_project = sys.argv[1]
gcp_location = sys.argv[2]
#config_file = sys.argv[3]
#
#if len(config_file) != 0:
#    if dco.valid_config(config_file):
#        param_file = "data_catalog_" + config_file + "_config.txt"
#        paramfile = open(param_file, 'r')
#    else:
#        print("Param file name is invalid: %s" %(config_file))
#        sys.exit(1)
#else:
#    print("Param file value incorrect")
#    sys.exit(1)

paramfile = open("data_catalog_create_ext_entries_config.txt", 'r')

lines = paramfile.readlines()

for i in lines[1:]:
    entry_group_id = i.split(',')[0].strip()
    entry_id = i.split(',')[1].strip()
    schema_path = i.split(',')[2].strip()
    linked_resource = i.split(',')[3].strip()

    args = '{"project_id": "%s", "location": "%s"}' %(gcp_project,gcp_location)
    print("Arguments passed as : %s" %(args))
    project_entry_groups = dco.list_entry_groups(args)
    
    if not bool(project_entry_groups) or not any(d["displayName"] == entry_group_id for d in project_entry_groups["entryGroups"]):
        print(f"Entry Group {entry_group_id} does not exists, creating....")
        args = '{"project_id": "%s", "location": "%s", "entry_group_id": "%s", "display_name": "%s", "description": "" }' %(gcp_project,gcp_location,entry_group_id,entry_group_id)
        print("Arguments passed as : %s" %(args))
        gcp_group_id =  dco.create_entry_group(args)
    else:
        gcp_group_id = [d["name"] for d in project_entry_groups["entryGroups"] if d["displayName"] == entry_group_id][0]
        print(f"entry_group_id {gcp_group_id} already exists")
        print(gcp_group_id)
    
    args = '{"parent": "%s"}' %(gcp_group_id) 
    gcp_group_entries = dco.list_entry(args)
    
    if not bool(gcp_group_entries) or not any(d["displayName"] == entry_id for d in gcp_group_entries["entries"]):
        print(f"External Entry {entry_id} does not exists in Group {entry_group_id} creating....")
        args = '{"parent": "%s", "entry_id": "%s", "path": "%s", "linked_resource": "%s"}' %(gcp_group_id,entry_id,schema_path,linked_resource)
        print("Arguments passed as : %s" %(args))
        gcp_entry = dco.create_entry(args)
    else:
        gcp_entry = [d["name"] for d in gcp_group_entries["entries"] if d["displayName"] == entry_id][0]
        print(f"External entry {entry_id} already exists in Group {entry_group_id}")
        print(gcp_entry)
