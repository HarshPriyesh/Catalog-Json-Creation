#####################################################################################################
# Program Name : data_catalog_operations                                                            #
# Purpose      : The script contains the python functions to perform various data catalog operations#
# Author       :                                                                                    #
#####################################################################################################

#####################################################################################################
# Import required modules                                                                           #
#####################################################################################################

from google.cloud import datacatalog_v1
import json
import requests
import google.auth
import google.auth.transport.requests
from google.cloud import storage
import re

storage_client = storage.Client()

schema_loc = "gs://optimal-sentry-342216_schema"

#####################################################################################################
# Get default credentials                                                                           #
#####################################################################################################
def get_auth_token():
    creds, projects = google.auth.default()
    auth_req = google.auth.transport.requests.Request()
    creds.refresh(auth_req)
    return creds.token

#####################################################################################################
# Read file from cloud storage to return as dict                                                    #
#####################################################################################################

def read_json_file(bucket, filepath, r_type):
    mappingbucket = storage_client.get_bucket(bucket)
    blob = mappingbucket.get_blob(filepath)
    b_json = blob.download_as_string()
    if r_type == 'json':
        j_dict = json.loads(b_json)
        return j_dict
    elif r_type == 'string':
        return b_json.decode("utf-8")

#####################################################################################################
# Write file to cloud storage                                                                       #
#####################################################################################################

def write_json_file(bucket, file_nm, w_string):
    mappingbucket = storage_client.get_bucket(bucket)
    blob = mappingbucket.blob(file_nm)
    blob.upload_from_string(w_string)

#####################################################################################################
# Check if file contains any special charecters                                                     #
#####################################################################################################
def valid_config(file_nm):
    spe_chars = re.compile('[@!#$%^&*()<>.?/\-|}{~:]')
    ret_val = 0
    if(spe_chars.search(file_nm) == None):
        if not any(1 for i in file_nm if i.isspace()):
            ret_val = 1
        else:
            print("No Spaces allowed in the config filename")
    else:
        print("Allowed special charecters in config file Name : _")
    return ret_val
            


#####################################################################################################
# Initialize Data catalog Object                                                                    #
#####################################################################################################
datacatalog = datacatalog_v1.DataCatalogClient()

#####################################################################################################
# Create data catalog entry group                                                                   #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "entry_group_id": "custom_entry", "display_name": "custom_entry", "description": "This is a custom entry Group" }'

def create_entry_group(args):
    p_args = json.loads(args)
    entry_group_obj = datacatalog_v1.types.EntryGroup()
    entry_group_obj.display_name = p_args["display_name"]
    entry_group_obj.description = p_args["description"]
    try:
        entry_group = datacatalog.create_entry_group(
            parent=datacatalog_v1.DataCatalogClient.common_location_path(
                p_args["project_id"], p_args["location"]
            ),
            entry_group_id=p_args["entry_group_id"],
            entry_group=entry_group_obj,
        )
        
        return entry_group.name
        
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# Delete data catalog entry group                                                                   #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "entry_group_id": "custom_entry"}'

def delete_entry_group(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    entry_group_id = p_args.get("entry_group_id")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/entryGroups/{entry_group_id}"
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}?force=true"
    try:
        response = requests.delete(url, headers=headers)
        if response.status_code == 200:
            print("Deleted entry group: {}".format(entry_group_id))
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 


#####################################################################################################
# List entry groups in the project                                                                  #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1"}'

def list_entry_groups(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/projects/{project_id}/locations/{location}/entryGroups"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# list data catalog entry group                                                                     #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "entry_group_id": "custom_entry"}'

def list_entry(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    entry_group_id = p_args.get("entry_group_id")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/entryGroups/{entry_group_id}"
    
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}/entries"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 


#####################################################################################################
# Create data catalog entry                                                                         #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "entry_group_id": "custom_entry", "entry_id": "hive_ext_tbl", "display_name": "hive_ext_tbl", "path": "", "bucket": "optimal-sentry-342216_schema", "linked_resource": "abc.txt" }'

def create_entry(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    entry_group_id = p_args.get("entry_group_id")
    entry_id = p_args.get("entry_id")
    parent = p_args.get("parent")
    bucket = p_args.get("bucket")
    linked_resource = p_args.get("linked_resource")
    
    if bucket == None:
        catlog_json_path = p_args["path"].split("/")
        bucket = catlog_json_path[2]
        json_path = "/".join(catlog_json_path[3:]) 
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/entryGroups/{entry_group_id}"
    
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    entry_name = entry_id.replace(".","_")
    url = f"https://datacatalog.googleapis.com/v1/{parent}/entries?entryId={entry_name}"
    display_name = p_args.get("display_name")
    if display_name == None:
        display_name = entry_name
    schema_path = json_path + "/" + entry_id + ".json"
    schema = read_json_file(bucket, schema_path, 'json')
    
    if linked_resource == None or linked_resource == "":
        linked_resource = schema.get("linked_resource")
    
    ext_ent_schema = schema.get("schema")["columns"]
    
    r_json = "{'displayName': '%s', 'userSpecifiedType': 'Table', 'userSpecifiedSystem': 'HIVE', 'linkedResource': '%s', 'schema': {'columns': %s }}" %(display_name,linked_resource,ext_ent_schema)
    try:
        response = requests.post(url, headers=headers, data=r_json)
        if response.status_code == 200:
           ret_json = json.loads(response.text)
           return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e))    

#####################################################################################################
# Delete data catalog entry                                                                         #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "entry_group_id": "custom_entry", "entry_id": "hive_ext_tbl"}'

def delete_entry(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    entry_group_id = p_args.get("entry_group_id")
    entry_id = p_args.get("entry_id")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/entryGroups/{entry_group_id}/entries/{entry_id}"
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}"
    try:
        response = requests.delete(url, headers=headers)
        if response.status_code == 200:
            print("Deleted entry: {}".format(entry_id))
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 
        
#####################################################################################################
# get data catalog entry                                                                            #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "entry_group_id": "custom_entry", "entry_id": "hive_ext_tbl", "attribute": "schema"}'

def get_entry(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    entry_group_id = p_args.get("entry_group_id")
    entry_id = p_args.get("entry_id")
    list_attr = p_args.get("attribute")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/entryGroups/{entry_group_id}/entries/{entry_id}"
    
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# get a Tag Template                                                                                #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "tag_template_id": "custom_tag_template"}'

def get_tag_template(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    tag_template_id = p_args.get("tag_template_id")
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/projects/{project_id}/locations/{location}/tagTemplates/{tag_template_id}"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
    except Exception as e:
        print("[ERROR]:       %s" %(e))

#####################################################################################################
# create a Tag Template                                                                             #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "display_name": "custom_tag_template", \
#          "field": [{"field_name":"contains_pii", "field_display_name": "pii_field"}, \
#                    {"field_name":"finance_data", "field_display_name": "finance_data"}], \
#          "tag_template_id": "custom_tag_template"}'

def create_tag_template(args):
    p_args = json.loads(args)
    tag_template = datacatalog_v1.types.TagTemplate()
    tag_template.display_name = p_args["display_name"]
    for field in p_args["field"]:
        tag_template.fields[field["field_name"]] = datacatalog_v1.types.TagTemplateField()
        tag_template.fields[field["field_name"]].display_name = field["field_display_name"]
        tag_template.fields[
            field["field_name"]
        ].type_.primitive_type = datacatalog_v1.types.FieldType.PrimitiveType.STRING
    
    expected_template_name = datacatalog_v1.DataCatalogClient.tag_template_path(p_args["project_id"], p_args["location"], p_args["tag_template_id"])
    
    try:
        tag_template = datacatalog.create_tag_template(
            parent="projects/%s/locations/%s" %(p_args["project_id"],p_args["location"]),
            tag_template_id=p_args["tag_template_id"],
            tag_template=tag_template,
        )
        print(f"Created template: {tag_template.name}")
    except Exception as e:
        print("[ERROR]:       %s" %(e))

#####################################################################################################
# delete a Tag Template                                                                             #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "tag_template_id": "custom_tag_template"}'

def delete_tag_template(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    tag_template_id = p_args.get("tag_template_id")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/tagTemplates/{tag_template_id}"
        
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}?force=true"
    try:
        response = requests.delete(url, headers=headers)
        if response.status_code == 200:
            print("Deleted Tag Template: {}".format(tag_template_id))
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# create a Tag Template  field                                                                      #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "tag_template_id": "custom_tag_template", \
#          "field_name":"contains_pii", "field_display_name": "pii_field"}'

def add_tag_template_field(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    tag_template_id = p_args.get("tag_template_id")
    field_name = p_args.get("field_name")
    field_display_name = p_args.get("field_display_name")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/tagTemplates/{tag_template_id}"
    
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}/fields?tagTemplateFieldId={field_name}"
    
    r_json = "{'displayName': '%s', 'type':{'primitiveType': 'STRING'}}" %(field_display_name)
    try:
        response = requests.post(url, headers=headers, data=r_json)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
    except Exception as e:
        print("[ERROR]:       %s" %(e))

#####################################################################################################
# delete a Tag Template field                                                                       #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "tag_template_id": "custom_tag_template", "tag_template_field": "account_pii"}'

def delete_tag_template_field(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    tag_template_id = p_args.get("tag_template_id")
    tag_template_field = p_args.get("tag_template_field")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/tagTemplates/{tag_template_id}/fields/{tag_template_field}"
        
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}?force=true"
    try:
        response = requests.delete(url, headers=headers)
        if response.status_code == 200:
            print("Deleted Tag Template: {}".format(tag_template_id))
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 
        
#####################################################################################################
# create a Tag                                                                                      #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", \
#          "field": [{"contains_pii":["row_key"]}, \
#                    {"finance_data":["trans" , "weight"]}] \
#          "tag_template_id": "test_template", "tag_name": "custom-field-tag", 
#          "entry_group_id": "custom_entry", "entry_id": "hive_ext_tbl"}'

def attach_tag(args):
    p_args = json.loads(args)
    project_id = p_args["project_id"]
    location = p_args["location"]
    entry_group_id = p_args["entry_group_id"]
    entry_id = p_args["entry_id"]
    #tag_name = p_args["tag_name"]
    template_name = p_args["tag_template_id"]
    tag_template = f"projects/{project_id}/locations/{location}/tagTemplates/{template_name}"
    #tag_columns = ",".join([key for i in p_args["field"] for key in i.values()])
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    tag_fields = {}
    for i in p_args["field"]:
        for k,v in i.items():
            for fields in v: 
                tag_fields[k] = {"stringValue" : fields}
                tag_name = "tag_" + fields
                r_json = "{'column': '%s', 'fields': %s , 'name': '%s', 'template': '%s'}" %(fields,tag_fields,tag_name,tag_template)
                url = f"https://datacatalog.googleapis.com/v1/projects/{project_id}/locations/{location}/entryGroups/{entry_group_id}/entries/{entry_id}/tags"
                try:
                    response = requests.post(url, headers=headers, data=r_json)
                    if response.status_code == 200:
                        ret_json = json.loads(response.text)
                        return ret_json
                    else:
                        err_text = json.loads(response.text)
                        raise Exception("%s" %(err_text["error"]["message"]))
                except Exception as e:
                    print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# List Tags                                                                                         #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "entry_group_id": "custom_entry", "entry_id": "hive_ext_tbl"}'

def get_entry_tags(args):
    p_args = json.loads(args)
    project_id = p_args["project_id"]
    location = p_args["location"]
    entry_group_id = p_args["entry_group_id"]
    entry_id = p_args["entry_id"]
    #list_attr = p_args["attribute"]
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/projects/{project_id}/locations/{location}/entryGroups/{entry_group_id}/entries/{entry_id}/tags"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 


#####################################################################################################
# delete a Tag                                                                                      #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "tag_id": "CbbUAUdgayis", "entry_group_id": "custom_entry", "entry_id": "hive_ext_tbl"}'

def delete_tag(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    entry_group_id = p_args.get("entry_group_id")
    entry_id = p_args.get("entry_id")
    tag_id = p_args.get("tag_id")
    parent = p_args.get("parent")
    
    if parent == None :
        parent = f"projects/{project_id}/locations/{location}/entryGroups/{entry_group_id}/entries/{entry_id}/tags/{tag_id}"
    
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}"
    try:
        response = requests.delete(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e))

#####################################################################################################
# Create a Policy Tag Taxonomy                                                                      #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "display_name": "test_policy_taxonomy", "activatedPolicyTypes": "FINE_GRAINED_ACCESS_CONTROL", "description": "This is a test Taxonomy"}'
# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "display_name": "test_policy_taxonomy_1", "activatedPolicyTypes": "POLICY_TYPE_UNSPECIFIED", "description": "This is a test Taxonomy"}'

def create_taxonomy(args):
    p_args = json.loads(args)
    project_id = p_args["project_id"]
    location = p_args["location"]
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/projects/{project_id}/locations/{location}/taxonomies"
    display_name = p_args["display_name"]
    description = p_args["description"]
    activatedPolicyTypes = p_args["activatedPolicyTypes"]
    r_json = "{'activatedPolicyTypes': ['%s'], 'displayName': '%s', 'description': '%s'}" %(activatedPolicyTypes,display_name,description)
    try:
        response = requests.post(url, headers=headers, data=r_json)
        if response.status_code == 200:
           print("Created Taxonomy : {}".format(display_name))
           ret_json = json.loads(response.text)
           return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e))   

#####################################################################################################
# delete a Taxonomy                                                                                 #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "tag_id": "7630787796509927053"}'

def delete_taxonomy(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    tag_id = p_args.get("tag_id")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/taxonomies/{tag_id}"
        
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}"
    try:
        response = requests.delete(url, headers=headers)
        if response.status_code == 200:
            print("Deleted Taxonomy: {}".format(tag_id))
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e))

#####################################################################################################
# List all taxonomies                                                                               #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1"}'

def list_taxonomies(args):
    p_args = json.loads(args)
    project_id = p_args["project_id"]
    location = p_args["location"]
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/projects/{project_id}/locations/{location}/taxonomies"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# List Taxonomy                                                                                     #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "tag_id": "7752319809005766449", "list_attr": "name"}'

def get_tags(args):
    p_args = json.loads(args)
    project_id = p_args["project_id"]
    location = p_args["location"]
    tag_id = p_args["tag_id"]
    list_attr = p_args["list_attr"]
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/projects/{project_id}/locations/{location}/taxonomies/{tag_id}"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            if len(list_attr) != 0:
                print(ret_json[list_attr])
            else:
                print(ret_json)
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 


#####################################################################################################
# create policy tags                                                                                #
#####################################################################################################

#args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "taxonomy_id": "1399982455800889581",\
#         "display_name": "P3_tag", "description": "Taging objects", "parentPolicyTag": ""}'

#args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "taxonomy_id": "1399982455800889581",\
#         "display_name": "C2_tag", "description": "Taging objects", "parentPolicyTag": "projects/optimal-sentry-342216/locations/us-central1/taxonomies/1399982455800889581/policyTags/3272372478059513631"}'

#args = '{"parent": "projects/optimal-sentry-342216/locations/us-central1/taxonomies/1399982455800889581",\
#         "display_name": "C2_tag", "description": "Taging objects", "parentPolicyTag": "projects/optimal-sentry-342216/locations/us-central1/taxonomies/1399982455800889581/policyTags/3272372478059513631"}'

def create_policy_tags(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    taxonomy_id = p_args.get("taxonomy_id")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/taxonomies/{taxonomy_id}"
    
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}/policyTags"
    display_name = p_args.get("display_name")
    description = p_args.get("description")
    parentPolicyTag = p_args.get("parentPolicyTag")
    r_json = "{'displayName': '%s', 'description': '%s', 'parentPolicyTag': '%s'}" %(display_name,description,parentPolicyTag)
    try:
        response = requests.post(url, headers=headers, data=r_json)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# list all policy tags in a taxonomy                                                                #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "taxonomy_id": "1399982455800889581"}'
# args = '{"parent": "projects/optimal-sentry-342216/locations/us-central1/taxonomies/1399982455800889581"}'

def list_policy_tags(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    taxonomy_id = p_args.get("taxonomy_id")
    parent = p_args.get("parent")
    
    if parent == None:
        parent = f"projects/{project_id}/locations/{location}/taxonomies/{taxonomy_id}"
    
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}/policyTags?pageSize=100"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# list policy tags                                                                                  #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "taxonomy_id": "1399982455800889581", \
#          "policytag": "3272372478059513631", "list_attr": "name"}'

def get_policy_tags(args):
    p_args = json.loads(args)
    project_id = p_args["project_id"]
    location = p_args["location"]
    taxonomy_id = p_args["taxonomy_id"]
    policytag = p_args["policytag"]
    list_attr = p_args["list_attr"]
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/projects/{project_id}/locations/{location}/taxonomies/{taxonomy_id}/policyTags/{policytag}"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            if len(list_attr) != 0:
                print(ret_json[list_attr])
            else:
                print(ret_json)
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# delete a Policy Tag                                                                               #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "taxonomy_id": "1399982455800889581", \
#          "policytag": "3272372478059513631"}'

def delete_policy_tag(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    taxonomy_id = p_args.get("taxonomy_id")
    policytag = p_args.get("policytag")
    parent = p_args.get("parent")
    if parent == None :
        parent = f"projects/{project_id}/locations/{location}/taxonomies/{taxonomy_id}/policyTags/{policytag}"
    
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}"
    try:
        response = requests.delete(url, headers=headers)
        if response.status_code == 200:
            print("Deleted Taxonomy: {}".format(policytag))
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e))

#####################################################################################################
# set IAM roles policy tags                                                                         #
#####################################################################################################

#args = '{"project_id": "optimal-sentry-342216", "location": "us-central1", "taxonomy_id": "1399982455800889581",\
#         "tag_id": "6648635768436896990", "member": "user:tghosh.hit@gmail.com", "role": "roles/datacatalog.categoryFineGrainedReader"}'

def setIam_polict_tags(args):
    p_args = json.loads(args)
    project_id = p_args.get("project_id")
    location = p_args.get("location")
    taxonomy_id = p_args.get("taxonomy_id")
    tag_id = p_args.get("tag_id")
    parent = p_args.get("parent")
    if parent == None :
        parent = f"projects/{project_id}/locations/{location}/taxonomies/{taxonomy_id}/policyTags/{tag_id}"
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://datacatalog.googleapis.com/v1/{parent}:setIamPolicy"
    member = p_args.get("member")
    role = p_args.get("role")
    r_json = "{'policy': {'bindings': [{'members':['%s'], 'role': '%s'}]}}" %(member,role)
    try:
        response = requests.post(url, headers=headers, data=r_json)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# BigQuery get schema                                                                               #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "dataset_id": "bq_internal", "table_id": "detail_record_part_1"}'

def get_bq_schema(args):
    p_args = json.loads(args)
    project_id = p_args["project_id"]
    dataset_id = p_args["dataset_id"]
    table_id = p_args["table_id"]
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    url = f"https://bigquery.googleapis.com/bigquery/v2/projects/{project_id}/datasets/{dataset_id}/tables/{table_id}"
    try:
        response = requests.get(url, headers=headers)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# Tag BQ table                                                                                      #
#####################################################################################################

# args = '{"project_id": "optimal-sentry-342216", "dataset_id": "bq_internal", "table_id": "detail_record_part_1",\
#          "t_column": "row_key",\ 
#          "tag_id": "projects/optimal-sentry-342216/locations/us-central1/taxonomies/1399982455800889581/policyTags/6349120158607913461",\
#          "operation": "add"}'

# args = '{"project_id": "optimal-sentry-342216", "dataset_id": "bq_internal", "table_id": "detail_record_part_1",\
#          "t_column": "row_key",\ 
#          "tag_id": "projects/optimal-sentry-342216/locations/us-central1/taxonomies/1399982455800889581/policyTags/6349120158607913461",\
#          "operation": "remove"}'

def tag_bq_tbl(args):
    p_args = json.loads(args)
    project_id = p_args["project_id"]
    dataset_id = p_args["dataset_id"]
    table_id = p_args["table_id"]
    tags = p_args["tags"]
    #t_column = p_args["t_column"]
    #tag_id = p_args["tag_id"]
    #operation = p_args["operation"]
    token = "Bearer " + get_auth_token()
    headers = {'Authorization': token, 'Content-Type': 'application/json; charset=utf-8'}
    bq_schema_args = f'"project_id": "{project_id}", "dataset_id": "{dataset_id}", "table_id": "{table_id}"'
    bq_schema = get_bq_schema("{"+bq_schema_args+"}")
    
    tagged_schema = []
    for i in bq_schema["schema"]["fields"]:
        t_field = i.copy()
        
        for j in tags:
            
            if i["name"].lower() == j["t_column"].lower() :
                if j["operation"] == "add" and i.get("policyTags") == None :
                    t_field["policyTags"] = {}
                    t_field["policyTags"]["names"] = [j["tag_id"]]
                elif j["operation"] == "remove" and i.get("policyTags") != None and i["policyTags"]["names"][0] == j["tag_id"]:
                    t_field["policyTags"] = {}
        
        tagged_schema.append(t_field)
    
    url = f"https://bigquery.googleapis.com/bigquery/v2/projects/{project_id}/datasets/{dataset_id}/tables/{table_id}"
    r_json = "{'schema': { 'fields': %s }}" %(tagged_schema)
    try:
        response = requests.patch(url, headers=headers, data=r_json)
        if response.status_code == 200:
            ret_json = json.loads(response.text)
            return ret_json
        else:
            err_text = json.loads(response.text)
            raise Exception("%s" %(err_text["error"]["message"]))
            
    except Exception as e:
        print("[ERROR]:       %s" %(e)) 

#####################################################################################################
# extract schema from an atlas extract                                                                                      #
#####################################################################################################

# args = '{"atlas_json": "gs://optimal-sentry-342216_schema/atlas_json/schema_db.detail_record.json", 
#          "catalog_json": "gs://optimal-sentry-342216_schema/datacatalog_json/schema_db.detail_record.json"}'
    
def get_json_extract(args):
    p_args = json.loads(args)
    atlas_json_path = p_args["atlas_json"].split("/")
    catlog_json_path = p_args["catalog_json"].split("/")
    bucket = atlas_json_path[2]
    json_path = "/".join(atlas_json_path[3:])
    atlas_schema = read_json_file(bucket, json_path, 'json')
    datacatalog_json = {}
    datacatalog_json["name"] = atlas_schema["definition"]["values"]["qualifiedName"].split("@")[0]
    #datacatalog_json["description"] = None
    datacatalog_json["displayName"] = atlas_schema["definition"]["values"]["qualifiedName"].split("@")[0]
    datacatalog_json["linked_resource"] = None
    col_list = []
    for col in atlas_schema["definition"]["values"]["columns"]:
        col_dict = {}
        col_dict["column"] = col["values"]["name"]
        #col_dict["description"] = col["values"]["description"]
        col_dict["mode"] = "NULLABLE"
        if re.compile('.*char.*').match(col["values"]["type"].lower()):
            col_dict["type"] = "STRING"
        elif col["values"]["type"].lower() == "binary":
            col_dict["type"] = "BYTES"
        elif re.compile('.*int$').match(col["values"]["type"].lower()):
            col_dict["type"] = "INTEGER"
        elif re.compile('^decimal.*').match(col["values"]["type"].lower()):
            col_dict["type"] = "FLOAT"
        elif re.compile('^numeric.*').match(col["values"]["type"].lower()):
            col_dict["type"] = "FLOAT"
        else:
            col_dict["type"] = col["values"]["type"].lower()
        
        col_list.append(col_dict)
    datacatalog_json["schema"] = {}
    datacatalog_json["schema"]["columns"] = col_list
    json_s = json.dumps(datacatalog_json)
    w_bucket = catlog_json_path[2]
    json_path = "/".join(catlog_json_path[3:])
    write_json_file(w_bucket, json_path, json_s)
    
    
