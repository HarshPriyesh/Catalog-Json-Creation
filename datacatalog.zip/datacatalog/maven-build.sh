#!/bin/bash
mvn -s settings.xml clean package