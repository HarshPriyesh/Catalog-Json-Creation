import datetime
import pendulum

from airflow import models
from airflow.providers.google.cloud.operators import dataproc

PROJECT = models.Variable.get('dataproc_project', 'default')
REGION = models.Variable.get('region', 'default')
DATAPROC_CLUSTER = models.Variable.get('dataproc_cluster_core_05', 'default')
CODE_CONFIG_STAGING_BUCKET = models.Variable.get('config_staging_bucket', 'default')
CATALOG_PROJ = models.Variable.get('datacatalog_project', 'default')
CATALOG_LOC = models.Variable.get('region', 'default')

JARS = [f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/data_catalog_module/python/data_catalog_create_ext_entries.py',
        f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/data_catalog_module/python/data_catalog_operations.py',
        f'gs://{CODE_CONFIG_STAGING_BUCKET}/engine/data_catalog_module/config/data_catalog_create_ext_entries_config.txt']

QUERY = [f'''sh chmod 755 * ; sh python3 data_catalog_create_ext_entries.py {CATALOG_PROJ} {CATALOG_LOC} ''']
PIG_JOB_SCRIPT = {
    "reference": {"project_id": PROJECT},
    "placement": {"cluster_name": DATAPROC_CLUSTER},
    "pig_job": {
        "jar_file_uris": JARS,
        "query_list": {"queries": QUERY},
    },
    "labels": {
        "job_name": "ap_edhmigr_datacatalog_create_extentries",
        "application": "datacatalog",
        "layer": "cdm-metadata-load",
    },
}

default_dag_args = {
    'retries': 0,
    'retry_delay': datetime.timedelta(minutes=5),
    'project_id': PROJECT,
    'location': REGION,
    'region': REGION,
}

dag = models.DAG(
    dag_id='ap_edhmigr_datacatalog_create_extentries',
    start_date=pendulum.datetime(2022, 7, 10, tz="Europe/London"),
    schedule_interval=None,
    catchup=False,
    default_args=default_dag_args,
    tags=['dataproc', 'datacatalog', 'create_ext_entries'],
)

pig_job = dataproc.DataprocSubmitJobOperator(
    task_id="pig_job",
    job=PIG_JOB_SCRIPT,
    asynchronous=False,
    dag=dag)
