# set environment variables
source composer/setup/cli_variables.sh

# trigger dag, poll for status, print logs
sh composer/setup/run.sh --dag_id=ap_edh_eph_datacatalog_atlas_extract --max_retries=11 --poll_interval=10
