
for i in $@
do
  case $i in
    -d=*|--dag_id=*)
      DAG_ID="${i#*=}"
      shift
      ;;
    # -im=*|--import=*)
    #   IMPORT="${i#*=}"
    #   shift
    #   ;;
    -r=*|--max_retries=*)
      RETRIES="${i#*=}"
      shift
      ;;
    -i=*|--poll_interval=*)
      INTERVAL="${i#*=}"
      shift
      ;;
#    -rd=*|--run_date=*)
#      RUNDATE="${i#*=}"
#      shift
#      ;;
    # -t=*|--timeout=*)
    #   TIMEOUT="${i#*=}"
    #   shift
    #   ;;
    *)
      ;;
  esac
done

# set defaults
IMPORT=${IMPORT:-false}
INTERVAL=${INTERVAL:-30}
TIMEOUT=${TIMEOUT:-300}
RETRIES=${RETRIES:-4}

# RETRIES=$((TIMEOUT / INTERVAL))
echo -e "\n---- starting run.sh ----"
echo "dag_id: ${DAG_ID}"
# echo "import=${IMPORT}"
echo "poll_interval: ${INTERVAL}"
echo "timeout: ${TIMEOUT}"
echo "max_retries: ${RETRIES}"
#echo "run_date: ${RUNDATE}"

export DAGS_FOLDER=`gcloud composer environments describe $COMPOSER_ENVIRONMENT --location $COMPOSER_REGION --format "value(config.dagGcsPrefix)"`; echo "dags folder: $DAGS_FOLDER"
export LOGS_FOLDER=${DAGS_FOLDER::-5}/logs; echo "logs folder: $LOGS_FOLDER"
export RUN_ID=$(date '+%Y-%m-%dT%H:%M:%S'); echo "run_id: $RUN_ID"
export final_status=''

function composer_info {
  # gcloud composer environments storage dags list --environment $COMPOSER_ENVIRONMENT
  # echo ""
  # gsutil ls -r $DAGS_FOLDER
  echo ""
  gcloud composer environments run $COMPOSER_ENVIRONMENT dags list
  # gcloud composer environments run $COMPOSER_ENVIRONMENT dags delete -- $DAG_ID
  # gsutil rm $DAGS_FOLDER/$DAG_ID
}

# function import_dag {
#   if $IMPORT; then
#     echo -e "\n---- importing dag ----"
#     echo $DAG_FILE_PATH
#     gcloud composer environments storage dags import --environment $COMPOSER_ENVIRONMENT --source $DAG_FILE_PATH
#     # if [ $? -ne 0 ]; then
#     #   echo "error with dag import"
#     #   exit $error
#     # fi
#     echo -e "\n---- waiting for 30 seconds ----"
#     sleep 30
#   fi
# }

# trigger and retrun exec_date
function trigger_dag {
  echo -e "\n---- triggering dag ---- $DAG_ID ----"
  #y={\"rundate\":\"$RUNDATE\"}
  #echo "gcloud composer environments run $COMPOSER_ENVIRONMENT dags trigger -- -r $RUN_ID $DAG_ID --conf $y"
  #x=$(gcloud composer environments run $COMPOSER_ENVIRONMENT dags trigger -- -r $RUN_ID $DAG_ID --conf $y)
  echo "gcloud composer environments run $COMPOSER_ENVIRONMENT dags trigger -- -r $RUN_ID $DAG_ID"
  x=$(gcloud composer environments run $COMPOSER_ENVIRONMENT dags trigger -- -r $RUN_ID $DAG_ID)
  # if [ $? -ne 0 ]; then
  #   echo "error while triggering dag"
  #   exit 1
  # fi
  d=$( echo $x | cut -d '@' -f2 | cut -d ' ' -f2 )
  EXEC_DATE=${d:0:25};
  echo EXEC_DATE=$EXEC_DATE
}

function check_status {
  gcloud composer environments run $COMPOSER_ENVIRONMENT dags state -- $DAG_ID $EXEC_DATE > s.txt
  status=$(tail -n 2 s.txt | head -n 1); rm s.txt
  # success, running, failed
  echo $status
}

function check_status_retry {
  local retries=$RETRIES
  local interval=$INTERVAL # in seconds
  local attempt=0
  local current_status='inital'
  local timeout=$TIMEOUT

  while [ $attempt -lt $retries ]
  do
    echo -e "\n---- checking status: attempt" $(( attempt + 1 )) "----"

    current_status=$(check_status)
    echo current_status: $current_status

    echo "---- tasks states-for-dag-run dag: $DAG_ID ----"
    gcloud composer environments run $COMPOSER_ENVIRONMENT tasks states-for-dag-run -- --output table -v $DAG_ID $RUN_ID
      # if [ $? -ne 0 ]; then
      #   echo "error while checking dag status"
      #   exit 1
      #   break
      # fi

    if [ $current_status = "success" ]; then
      export final_status=$current_status

      break
    elif [ $current_status = "failed" ]; then
      export final_status=$current_status
      break
    fi

    attempt=$(( attempt + 1 ))

    if [ $attempt -lt $retries ]; then
        echo "Retrying in $interval seconds..."
        sleep $interval
        interval=$(( interval * 2 ))
    fi
  done
}

function read_composer_logs {
  echo -e "\n---- reading Composer logs ----\n"
  gsutil cat -h $LOGS_FOLDER/dag_id=$DAG_ID/run_id=$RUN_ID/**/attempt=*.log
}

function read_dataproc_logs {
  echo -e "\n---- reading Dataproc logs ----\n"

  gsutil cat -h $LOGS_FOLDER/dag_id=$DAG_ID/run_id=$RUN_ID/**/attempt=1.log > l.txt
  # job=$(head -n 21 l.txt | tail -n 1 | cut -d " " -f9); rm l.txt
  # job=$(awk '{print; if (match($0,"gcloud dataproc jobs wait")) exit}' l.txt | tail -n 1 | cut -d "'" -f2 | cut -d "\\" -f1); rm l.txt
  job=$(awk '{print; if (match($0,"Waiting for job")) exit}' l.txt | tail -n 1 | cut -d " " -f8)
  echo job: $job
  gcloud dataproc jobs wait $job --region europe-west2 --project ap-dcledh-bld-01-b158
}

function exit_with_dag_status {
  ## exit with status - TWS specific code
  echo dag status: $final_status
  # if [ $final_status = "success" ]; then
  #   exit 0
  if [ $final_status = "failed" ]; then
    exit 1
  fi;
}

composer_info;

# import_dag;

trigger_dag;

check_status_retry;

read_composer_logs;

read_dataproc_logs;

exit_with_dag_status;

