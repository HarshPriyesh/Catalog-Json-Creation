#!/bin/bash

#CATALOG_PROJ=${1}
#CATALOG_LOC=${2}

echo "CATALOG_PROJ : ${CATALOG_PROJ}"
echo "CATALOG_LOC : ${CATALOG_LOC}"

gs_loc="gs://ap-edhsta-bld-01-stb-euwe2-config-01/engine/data_catalog_module"
#gsutil -m cp python/* ${gs_loc}/python/
#gsutil -m cp config/bld-01/* ${gs_loc}/config/
#gsutil cat gs://ap-edh-bld-01-stb-euwe2-landing-01/datacatlog/catalog_json/curated_mppd.top_slice.json

if [[ $JOB_NAME = "ap-edhmigr-datacatalog-atlas-extract" ]]
then
    echo "****************************** Executing Pig Job  ****************************"
    gsutil cp config/bld-01/data_catalog_create_schema_json_config.txt ${gs_loc}/config/
    gcloud dataproc jobs submit pig \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --cluster=ap-dcledh-bld-01-dcl-euwe2-core-09 \
    --region=europe-west2 \
    --project=ap-dcledh-bld-01-b158 \
    --jars=${gs_loc}/python/extract_atlas_to_catalog_json.py,${gs_loc}/python/data_catalog_operations.py,${gs_loc}/config/data_catalog_create_schema_json_config.txt \
    -e="sh chmod 755 * ; sh python3 extract_atlas_to_catalog_json.py ${CATALOG_PROJ} ${CATALOG_LOC} catalog_create_schema_json"
elif [[ $JOB_NAME = "ap-edhmigr-datacatalog-create-extentries" ]]
then
    echo "****************************** Executing Pig Job  ****************************"
    gsutil cp config/bld-01/data_catalog_create_ext_entries_config.txt ${gs_loc}/config/
    gcloud dataproc jobs submit pig \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --cluster=${DATAPROC_CLUSTER} \
    --region=${REGION} \
    --project=${PROJECT_ID} \
    --jars=${gs_loc}/python/data_catalog_create_ext_entries.py,${gs_loc}/python/data_catalog_operations.py,${gs_loc}/config/data_catalog_create_ext_entries_config.txt \
    -e="sh chmod 755 * ; sh python3 data_catalog_create_ext_entries.py ${CATALOG_PROJ} ${CATALOG_LOC} create_ext_entries"
elif [[ $JOB_NAME = "ap-edhmigr-datacatalog-del-extentries" ]]
then
    echo "****************************** Executing Pig Job  ****************************"
    gsutil cp config/bld-01/data_catalog_delete_external_entries_config.txt ${gs_loc}/config/
    gcloud dataproc jobs submit pig \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --cluster=${DATAPROC_CLUSTER} \
    --region=${REGION} \
    --project=${PROJECT_ID} \
    --jars=${gs_loc}/python/data_catalog_delete_ext_entries.py,${gs_loc}/python/data_catalog_operations.py,${gs_loc}/config/data_catalog_delete_external_entries_config.txt \
    -e="sh chmod 755 * ; sh python3 data_catalog_delete_ext_entries.py ${CATALOG_PROJ} ${CATALOG_LOC} delete_external_entries"
elif [[ $JOB_NAME = "ap-edhmigr-datacatalog-tag-extentries" ]]
then
    echo "****************************** Executing Pig Job  ****************************"
    gsutil cp config/bld-01/data_catalog_tag_external_entries_config.txt ${gs_loc}/config/
    gcloud dataproc jobs submit pig \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --cluster=${DATAPROC_CLUSTER} \
    --region=${REGION} \
    --project=${PROJECT_ID} \
    --jars=${gs_loc}/python/data_catalog_tag_ext_entries.py,${gs_loc}/python/data_catalog_operations.py,${gs_loc}/config/data_catalog_tag_external_entries_config.txt \
    -e="sh chmod 755 * ; sh python3 data_catalog_tag_ext_entries.py ${CATALOG_PROJ} ${CATALOG_LOC} tag_external_entries"
elif [[ $JOB_NAME = "ap-edhmigr-datacatalog-del-tagextentries" ]]
then
    echo "****************************** Executing Pig Job  ****************************"
    gsutil cp config/bld-01/data_catalog_ext_entries_remove_tags_config.txt ${gs_loc}/config/
    gcloud dataproc jobs submit pig \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --cluster=${DATAPROC_CLUSTER} \
    --region=${REGION} \
    --project=${PROJECT_ID} \
    --jars=${gs_loc}/python/data_catalog_del_tag_ext_entries.py,${gs_loc}/python/data_catalog_operations.py,${gs_loc}/config/data_catalog_ext_entries_remove_tags_config.txt \
    -e="sh chmod 755 * ; sh python3 data_catalog_del_tag_ext_entries.py ${CATALOG_PROJ} ${CATALOG_LOC} ext_entries_remove_tags"
elif [[ $JOB_NAME = "ap-edhmigr-datacatalog-create-policytag" ]]
then
    echo "****************************** Executing Pig Job  ****************************"
    gsutil cp config/bld-01/data_catalog_manage_policy_tags_config.txt ${gs_loc}/config/
    gcloud dataproc jobs submit pig \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --cluster=${DATAPROC_CLUSTER} \
    --region=${REGION} \
    --project=${PROJECT_ID} \
    --jars=${gs_loc}/python/data_catalogs_policy_tags.py,${gs_loc}/python/data_catalog_operations.py,${gs_loc}/config/data_catalog_manage_policy_tags_config.txt \
    -e="sh chmod 755 * ; sh python3 data_catalogs_policy_tags.py ${CATALOG_PROJ} ${CATALOG_LOC} manage_policy_tags"
elif [[ $JOB_NAME = "ap-edhmigr-datacatalog-tag-bqtable" ]]
then
    echo "****************************** Executing Pig Job  ****************************"
    gsutil cp config/bld-01/data_catalog_tag_bigquery_col_config.txt ${gs_loc}/config/
    gcloud dataproc jobs submit pig \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --cluster=${DATAPROC_CLUSTER} \
    --region=${REGION} \
    --project=${PROJECT_ID} \
    --jars=${gs_loc}/python/data_catalog_bigquery_policy_tags.py,${gs_loc}/python/data_catalog_operations.py,${gs_loc}/config/data_catalog_tag_bigquery_col_config.txt \
    -e="sh chmod 755 * ; sh python3 data_catalog_bigquery_policy_tags.py ${CATALOG_PROJ} ${CATALOG_LOC} tag_bigquery_col"
elif [[ $JOB_NAME = "ap-edhmigr-datacatalog-create-tags" ]]
then
    echo "****************************** Executing Pig Job  ****************************"
    gsutil cp config/bld-01/data_catalog_manage_tag_template_config.txt ${gs_loc}/config/
    gcloud dataproc jobs submit pig \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --cluster=${DATAPROC_CLUSTER} \
    --region=${REGION} \
    --project=${PROJECT_ID} \
    --jars=${gs_loc}/python/data_catalog_create_tags.py,${gs_loc}/python/data_catalog_operations.py,${gs_loc}/config/data_catalog_manage_tag_template_config.txt \
    -e="sh chmod 755 * ; sh python3 data_catalog_create_tags.py ${CATALOG_PROJ} ${CATALOG_LOC} manage_tag_template"
fi
