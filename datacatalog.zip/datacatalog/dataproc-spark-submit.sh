#!/bin/bash

if [[ $JOB_NAME = "Job_Name" ]] #Jobname parameter mentioned in jenkins-parameters-file.yaml
then
    echo "****************************** Copying artifacts into Dataproc Staging bucket ******************************"
    gsutil cp ExampleJarFile.Jar gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/ExampleJarFile.Jar

    echo "****************************** Executing Spark Job ******************************"
    gcloud dataproc jobs submit spark \
    --cluster=${DATAPROC_CLUSTER} \
    --class=${MAIN_CLASS} \
    --jars="gs://${DATAPROC_STAGING_BUCKET}/${JOB_NAME}/ExampleJarFile.Jar" \
    --labels="owner=amrita-mukherjee","cost_centre"="413558","cmdb_appid=al14871","dataclassification=limited" \
    --region=${REGION} \
    --project=${PROJECT_ID}
fi