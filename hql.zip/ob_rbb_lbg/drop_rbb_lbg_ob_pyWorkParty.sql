-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty_stg  (
	CaseID	string,
	pyWorkParty_all ARRAY<STRUCT<subscript:STRING,pyWorkParty:struct<
	pyFirstName:string,
	pyLastName:string,
	pyFullName:string,
	pyLabel:string,
	pyPartyLabel:string,
	pyPosition:string,
	pyEmail1:string,
	pyWorkPhone:string
>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.CaseID"="/item/pyID/text()",
	"column.xpath.pyWorkParty_all"="/item/pyWorkParty"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat' 
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' 
LOCATION '${xmlSourcePath}' 
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=COBL_DEFAULT;
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=COBL_DEFAULT;
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty (
	CaseID	string,
	subscript string,
	pyFirstName	string,
	pyLastName	string,
	pyFullName	string,
	pyLabel	string,
	pyPartyLabel	string,
	pyPosition	string,
	pyEmail1	string,
	pyWorkPhone	string,
	bucked_column string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
STORED AS ORC TBLPROPERTIES ('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty_upd;
CREATE TABLE DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty_upd 
AS SELECT E.*,TRAN_DATE 
FROM (SELECT CaseID,
	HI.subscript,
	HI.pyWorkParty.pyFirstName,
	HI.pyWorkParty.pyLastName,
	HI.pyWorkParty.pyFullName,
	HI.pyWorkParty.pyLabel,
	HI.pyWorkParty.pyPartyLabel,
	HI.pyWorkParty.pyPosition,
	HI.pyWorkParty.pyEmail1,
	HI.pyWorkParty.pyWorkPhone 
FROM DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty_stg 
LATERAL VIEW EXPLODE(pyWorkParty_all) exploded as HI) E 
LEFT OUTER JOIN DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty T 
ON (E.CaseID = T.CaseID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty 
	WHERE CaseID IN (
	SELECT CaseID 
	FROM DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty_upd);

-- Inserting updates into the table
FROM DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty_upd
INSERT INTO DASD_COBL_ACQ.rbb_lbg_OB_pyWorkParty PARTITION (tran_date)
SELECT
	CaseID,
	subscript,
	pyFirstName,
	pyLastName,
	pyFullName,
	pyLabel,
	pyPartyLabel,
	pyPosition,
	pyEmail1,
	pyWorkPhone,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_OB_pyWorkParty_stg;
drop table dasd_cobl_acq.rbb_lbg_OB_pyWorkParty_upd;