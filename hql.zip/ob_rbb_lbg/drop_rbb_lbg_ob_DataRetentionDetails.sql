-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_OB_DataRetentionDetails_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE DASD_COBL_ACQ.rbb_lbg_OB_DataRetentionDetails_stg (
	CaseID	string,
	DATA_RETENTION ARRAY<STRUCT<DataRetentionDetails:struct<
		LastUpdatedDateTime:string,
		pxObjClass:string,
		pzindexes:string,
		RetentionStatus:string,
		Status:string
>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.CaseID"="/item/pyID/text()",
	"column.xpath.DATA_RETENTION"="/item/DataRetentionDetails"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat' 
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' 
LOCATION '${xmlSourcePath}' 
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=COBL_DEFAULT;
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=COBL_DEFAULT;
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS DASD_COBL_ACQ.rbb_lbg_OB_DataRetentionDetails (
	CaseID	string,
	LastUpdatedDateTime timestamp,
	pxObjClass string,
	pzindexes string,
	RetentionStatus string,
	Status string,
	bucked_column string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_OB_DataRetentionDetails_upd;
CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_ob_DataRetentionDetails_upd 
AS SELECT S.*, T.tran_date FROM
(SELECT CaseID,
	DRD.DataRetentionDetails.LastUpdatedDateTime,
	DRD.DataRetentionDetails.pxObjClass,
	DRD.DataRetentionDetails.pzindexes,
	DRD.DataRetentionDetails.RetentionStatus,
	DRD.DataRetentionDetails.Status
FROM dasd_cobl_acq.rbb_lbg_ob_DataRetentionDetails_stg 
LATERAL VIEW explode(DATA_RETENTION) exploded as DRD) S 
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_ob_DataRetentionDetails T 
ON (S.CaseID = T.CaseID);

--Deleting existing records to be replaced by their updates
DELETE FROM DASD_COBL_ACQ.rbb_lbg_OB_DataRetentionDetails 
	WHERE CaseID IN (
	SELECT CaseID 
	FROM DASD_COBL_ACQ.rbb_lbg_OB_DataRetentionDetails_upd);

-- Inserting updates into the table
FROM DASD_COBL_ACQ.rbb_lbg_OB_DataRetentionDetails_upd 
INSERT INTO DASD_COBL_ACQ.rbb_lbg_OB_DataRetentionDetails PARTITION (tran_date)
SELECT
	CaseID,
	timestamp(regexp_replace(LastUpdatedDateTime,'T|Z',' ')),
	pxObjClass,
	pzindexes,
	RetentionStatus,
	Status,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_OB_DataRetentionDetails_stg;
drop table dasd_cobl_acq.rbb_lbg_OB_DataRetentionDetails_upd;