SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_ob_master_leads (
	ref 	string
	,post 	string
	,full_post_code 	string
	,business_name 	string
	,name string
	,telephone_number 	string
	,altenative_phone_number 	string
	,email 	string
	,source_of_lead 	string
	,type_of_lead 	string
	,lending 	string
	,address 	string
	,referred_to string
	,pxCreateDateTime 	timestamp
	,pxUpdateDateTime 	timestamp
	,loaddate 	timestamp
	,brand 	string
	,bucked_column 	string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
STORED AS ORC TBLPROPERTIES('transactional'='true');


	
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_master_leads_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_master_leads_upd AS 
SELECT
	m.ref
	,m.post
	,m.full_post_code
	,m.business_name
	,m.name
	,m.telephone_number
	,m.altenative_phone_number
	,m.email
	,m.source_of_lead
	,m.type_of_lead
	,m.lending
	,m.address
	,m.referred_to
	,m.pxCreateDateTime
	,m.pxUpdateDateTime
	,m.loaddate
	,m.brand
from (select 
	MC.pyID as `ref`
	
	,case  when length(regexp_replace(TA.PostCode,' ','')) > 4 then
		UPPER(LTRIM( substring(regexp_replace(TA.PostCode,' ',''),1,length(regexp_replace(TA.PostCode,' ',''))-3) ) ) 
		else 
		UPPER(TA.PostCode) 
		end post
		
	,case  when length(regexp_replace(TA.PostCode,' ','')) > 4 then
		concat(	
		UPPER(LTRIM( substring(regexp_replace(TA.PostCode,' ',''),1,length(regexp_replace(TA.PostCode,' ',''))-3) ) ) 
		,' ',
		UPPER(LTRIM(substring(regexp_replace(TA.PostCode,' ',''),length(regexp_replace(TA.PostCode,' ',''))-2,3))) 
		)
		else 
		UPPER(TA.PostCode) 
		end	as full_post_code
		
	,MC.CompanyName as business_name
	,concat(PC.FirstName,' ',coalesce(PC.LastName,'')) as name
	,PC.PrimaryContactNumber as telephone_number
	,NULL as altenative_phone_number
	,PC.EMailAddress as email
	,'Digital Pilot' as source_of_lead
	,case when MC.BankingStatus = 'StartUp' then 'Start up' else MC.BankingStatus 
		end as type_of_lead
	,CASE WHEN lower(MC.ContactCustomerForBusinessLoan) = 'true' THEN 'Yes'
		ELSE 'No'
		end as lending
	,case when RTRIM(LTRIM(TA.AddressLineOne)) = RTRIM(LTRIM(coalesce(TA.AddressLineTwo,''))) then 
		concat(TA.AddressLineOne,' , ',coalesce(TA.pyCity,''))
		else RTRIM(concat(TA.AddressLineOne,' ',coalesce(TA.AddressLineTwo,''),' , ',coalesce(TA.pyCity,''))) 
		end as address
	,CASE  
		WHEN MC.CustomerType LIKE 'Non Incorporated Club, Society' THEN 'NCS - Clubs and Societies'
		WHEN MC.CustomerType LIKE 'Non Incorporated Charity' THEN 'NCS - Charities'
		WHEN MC.CustomerType LIKE 'Limited Liability Partnership' THEN 'NCS - LLP (Unsupported Entity)'
		WHEN PC.CountryOfResidence NOT LIKE 'United Kingdom' THEN 'NCS - Primary KAP is non UK resident'
		WHEN (
			substring(TA.PostCode,0,2) in
			('AB'
			,'DD'
			,'DG'
			,'EH'
			,'FK'
			,'G1'
			,'G2'
			,'G3'
			,'G4'
			,'G5'
			,'G6'
			,'G7'
			,'G8'
			,'HS'
			,'IV'
			,'KA'
			,'KW'
			,'KY'
			,'ML'
			,'PA'
			,'PH'
			,'TD'
			,'ZE'
			,'BT'
			) 
			AND
			BRAND = 'LBG'
			)
			THEN 'NCS - Scotland/Ireland Client Requesting LBG'
			WHEN 
			(substring(TA.PostCode,0,2) not in
			('AB'
			,'DD'
			,'DG'
			,'EH'
			,'FK'
			,'G1'
			,'G2'
			,'G3'
			,'G4'
			,'G5'
			,'G6'
			,'G7'
			,'G8'
			,'HS'
			,'IV'
			,'KA'
			,'KW'
			,'KY'
			,'ML'
			,'PA'
			,'PH'
			,'TD'
			,'ZE'
			,'BT'
			) 
			and
			Brand = 'BOS'
			)
			THEN 'NCS - Non Scotland/Ireland Client Requesting BOS'
			ELSE 'Lead Enquiries'
			END as referred_to
	--,Cast(MC.pxCreateDateTime as datetime) as pxCreateDateTime
	,MC.pxCreateDateTime as pxCreateDateTime
	,Mc.pxUpdateDateTime as pxUpdateDateTime
	,CURRENT_DATE as LoadDate
	,Brand
	--from Staging_First_Parse_RBB_OB_Updated_OB_CompanyDetails_Individual_KAPs As PC
	--into Master_RBB_Leads_Advised
	from dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs As PC
	inner join
	--Staging_First_Parse_RBB_OB_Updated as MC
	dasd_cobl_acq.rbb_lbg_ob_case as MC
	on PC.CaseID = MC.CaseID
	left join
	--Staging_First_Parse_RBB_OB_Updated_OB_CompanyDetails_Organisation_Address As TA
	dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Organisation_Address As TA
	on TA.CaseID = MC.CaseID
	--left join
	--Master_RBB_Leads_Advised 
	--on Master_RBB_Leads_Advised.OB_CASE_ID = MC.CaseID
	where 
		MC.Blocker is not null
		and MC.pyStatusWork = 'Pending-MandateAcceptance'
		and PC.isPrimaryContact like 'true'
		and PC.PrimaryContactNumber is not null
		and TA.subscript like 'Trading'
		and TA.PostCode is not null
		--and Master_RBB_Leads_Advised.OB_CASE_ID is null
		and MC.pxCreateDateTime >= '2017-06-01' --do not adjust this date, it should be hardcoded to Jun 1st
	order by 
		REFERRED_TO
		,pxUpdateDateTime
) as m
group by 
	m.ref
	,m.post
	,m.full_post_code
	,m.business_name
	,m.name
	,m.telephone_number
	,m.altenative_phone_number
	,m.email
	,m.source_of_lead
	,m.type_of_lead
	,m.lending
	,m.address
	,m.referred_to
	,m.pxCreateDateTime
	,m.pxUpdateDateTime
	,m.loaddate
	,m.brand;



--updating daily current_leads table
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_current_leads;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_current_leads AS 
	SELECT S.* 
	FROM dasd_cobl_acq.rbb_lbg_ob_master_leads_upd S
	LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_ob_master_leads T
	ON S.ref = T.ref
	WHERE T.ref is null;



--append current_leads to master_leads
FROM dasd_cobl_acq.rbb_lbg_ob_current_leads
INSERT INTO TABLE dasd_cobl_acq.rbb_lbg_ob_master_leads 
PARTITION (tran_date)
SELECT ref
	,post
	,full_post_code
	,business_name
	,name
	,telephone_number
	,altenative_phone_number
	,email
	,source_of_lead
	,type_of_lead
	,lending
	,address
	,referred_to
	,pxCreateDateTime
	,pxUpdateDateTime
	,loaddate
	,brand
	,"" as bucked_column
	,CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_master_leads_upd;
drop table dasd_cobl_acq.rbb_lbg_ob_current_leads;