SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_ob_master_leads (
	ref	string
	,post	string
	,full_post_code	string
	,business_name	string
	,switch_type	string
	,existing_sort_code	bigint
	,existing_account_number	bigint
	,date_account_opened	string
	,name	string
	,telephone_number	string
	,altenative_phone_number	string
	,email	string
	,source_of_lead	string
	,type_of_lead	string
	,lending	string
	,address	string
	,referred_to	string
	,pxCreateDateTime	timestamp
	,pxUpdateDateTime	timestamp
	,loaddate	timestamp
	,brand	string
	,bucked_column	string
	,lbg_sort_code	bigint
	,lbg_account_number	bigint
	,turnover	bigint
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
STORED AS ORC TBLPROPERTIES('transactional'='true');


DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_master_leads_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_master_leads_upd AS
SELECT
	m.ref
	,m.post
	,m.full_post_code
	,m.business_name
	,m.switch_type
	,m.existing_sort_code
	,m.existing_account_number
	,m.date_account_opened
	,m.name
	,m.telephone_number
	,m.altenative_phone_number
	,m.email
	,m.source_of_lead
	,m.type_of_lead
	,m.lending
	,m.address
	,m.pxCreateDateTime
	,m.pxUpdateDateTime
	,m.LoadDate
	,m.Brand
	,m.lbg_sort_code
	,m.lbg_account_number
	,m.turnover
from (SELECT
	ob.CaseID as `ref`
	,ad.PostCode as `post`
	,ad.PostCode as `full_post_code`
	,ob.CompanyName as `business_name`
	,sp.CASSSwitchOption as `switch_type`
	,sp.SortCode as `existing_sort_code`
	,sp.AccountNumber as `existing_account_number`
	,ob.PrimaryAccountOpenedDate as `date_account_opened`
	,concat(kap.FirstName,' ',coalesce(kap.LastName,'')) as `name`
	,kap.PrimaryContactNumber as `telephone_number`
	,NULL as `altenative_phone_number`
	,kap.EMailAddress as `email`
	,'Digital Pilot' as `source_of_lead`
	,CASE WHEN ob.BankingStatus='StartUp' then 'Start up' else ob.BankingStatus END as `type_of_lead`
	,CASE WHEN ob.ContactCustomerForBusinessLoan='true' then 'Yes' else 'No' END as `lending`
	,CASE WHEN RTRIM(LTRIM(ad.AddressLineOne)) = RTRIM(LTRIM(coalesce(ad.AddressLineTwo,'')))
		then concat(ad.AddressLineOne,' , ',coalesce(ad.pyCity,''))
		else RTRIM(concat(ad.AddressLineOne,' ',coalesce(ad.AddressLineTwo,''),' , ',coalesce(ad.pyCity,''))) 
		END as `address`
	,ob.pxCreateDateTime as `pxCreateDateTime`
	,ob.pxUpdateDateTime as `pxUpdateDateTime`
	,CURRENT_DATE as `LoadDate`
	,ob.Brand as `Brand`
	,ob.PrimarySortCode as `lbg_sort_code`
	,ob.PrimaryAccountNumber as `lbg_account_number`
	,ac.ForecastedAnnualTurnover as `turnover`
FROM dasd_cobl_acq.rbb_lbg_ob_case as ob

--LEFT JOIN dasd_cobl_acq.rbb_lbg_ob_master_leads as ma
--on ma.ref = ob.CaseID

LEFT JOIN dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs as kap
on kap.CaseID = ob.CaseID

LEFT JOIN dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Organisation_Address as ad
on ad.CaseID = ob.CaseID

LEFT JOIN dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Account as ac
on ac.CaseID = ob.CaseID

LEFT JOIN (SELECT
	CaseID
--	,SubProduct
	,CASSSwitchOption
	,AccountNumber
	,SortCode
	from dasd_cobl_acq.rbb_lbg_ob_selectedproducts_subproductlist
	where PGID = 'PG21') as sp
on sp.CaseID = ob.CaseID

LEFT JOIN dasd_cobl_acq.rbb_lbg_pf_case as pf
on pf.OriginatingCaseID = ob.CaseID

WHERE (
	--true for all cases
	ob.pxCreateOpName not like '%/LBM%'
	and kap.isPrimaryContact = 'true'
	and ad.subscript = 'Trading'

	and (
	
	--include all switcher cases when pf is resolved
	(ob.BankingStatus = 'Switcher' and pf.pyStatusWork = 'Resolved-Completed')
	or
	--include all lending cases at pending mandate accept
	(ob.ContactCustomerForBusinessLoan = 'true' and ob.pyStatusWork = 'Pending-MandateAcceptance')
))
) as m
group by
	m.ref
	,m.post
	,m.full_post_code
	,m.business_name
	,m.switch_type
	,m.existing_sort_code
	,m.existing_account_number	
	,m.date_account_opened
	,m.name
	,m.telephone_number
	,m.altenative_phone_number
	,m.email
	,m.source_of_lead
	,m.type_of_lead
	,m.lending
	,m.address
	,m.pxCreateDateTime
	,m.pxUpdateDateTime
	,m.LoadDate
	,m.Brand
	,m.lbg_sort_code
	,m.lbg_account_number
	,m.turnover
;


--get leads that have not been sent before
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_current_leads;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_current_leads AS
	SELECT S.*
	FROM dasd_cobl_acq.rbb_lbg_ob_master_leads_upd S
	LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_ob_master_leads T
	ON s.ref = T.ref
	WHERE T.ref is null;


--append current_leads into master_leads table
FROM dasd_cobl_acq.rbb_lbg_ob_current_leads
INSERT INTO TABLE dasd_cobl_acq.rbb_lbg_ob_master_leads 
PARTITION (tran_date)
SELECT
	ref
	,post
	,full_post_code
	,business_name
	,switch_type
	,existing_sort_code
	,existing_account_number
	,date_account_opened
	,name
	,telephone_number
	,altenative_phone_number
	,email
	,source_of_lead
	,type_of_lead
	,lending
	,address
	,NULL as referred_to
	,pxCreateDateTime
	,pxUpdateDateTime
	,loaddate
	,brand
	,"" as bucked_column
	,lbg_sort_code
	,lbg_account_number
	,turnover
	,CAST(${tempTranDate} AS INT) as tran_date
	;


	
-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_master_leads_upd;
drop table dasd_cobl_acq.rbb_lbg_ob_current_leads;
