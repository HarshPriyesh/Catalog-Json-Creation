-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address_stg  (
	pyID	string,
	Address ARRAY<STRUCT<subscript:STRING,Address:struct<
		AddressLineOne:STRING,
		AddressLineTwo:STRING,
		PostCode:STRING,
		pxObjClass:STRING,
		pyCity:STRING,
		pyCountry:STRING
>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
	"column.xpath.Address"="/item/CompanyDetailsPage/Organisation/Address"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address (
	pyID	string,
	subscript string,
	AddressLineOne string,
	AddressLineTwo string,
	PostCode string,
	pxObjClass string,
	pyCity string,
	pyCountry string,
	bucked_column string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');

--Exploding structures into records
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address_upd;
CREATE TABLE DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address_upd
  AS SELECT E.*,TRAN_DATE FROM
 (SELECT pyID,
  HI.subscript,
  HI.Address.AddressLineOne,
  HI.Address.AddressLineTwo,
  HI.Address.PostCode,
  HI.Address.pxObjClass,
  HI.Address.pyCity,
  HI.Address.pyCountry
  FROM DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address_stg
  LATERAL VIEW EXPLODE(Address) exploded as HI) E
  LEFT OUTER JOIN DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address T
  ON (E.pyID = T.pyID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address
	WHERE pyID IN (
	SELECT pyID
	FROM DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address_upd);

-- Inserting updates into the table
FROM DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address_upd
INSERT INTO DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Organisation_Address PARTITION (tran_date)
SELECT
	pyID,
	subscript,
	AddressLineOne,
	AddressLineTwo,
	PostCode,
	pxObjClass,
	pyCity,
	pyCountry,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Organisation_Address_stg;
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Organisation_Address_upd;
