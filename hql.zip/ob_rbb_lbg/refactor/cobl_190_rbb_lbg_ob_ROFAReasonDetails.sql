-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails_stg  (
	pyID	string,
	ROFAReasonDetails ARRAY<STRUCT<subscript:STRING,ROFAReasonDetails:struct<
	Customer:string,
	Details:string,
	PBA:string,
	pxCreateDateTime:string,
	pxCreateOperator:string,
	pxCreateOpName:string,
	pxCreateSystemID:string,
	pxObjClass:string,
	ROFAField:string,
	SubField:string,
	Telephony:string
>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
	"column.xpath.ROFAReasonDetails"="/item/ROFAReasonDetails"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails (
	pyID	string,
	subscript bigint,
	Customer string,
	Details string,
	PBA string,
	pxCreateDateTime timestamp,
	pxCreateOperator string,
	pxCreateOpName string,
	pxCreateSystemID string,
	pxObjClass string,
	ROFAField string,
	SubField string,
	Telephony string,
	bucked_column string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');

--Exploding structures into records
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails_upd;
CREATE TABLE DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails_upd
  AS SELECT E.*,TRAN_DATE FROM
 (SELECT pyID,
  HI.subscript,
  	HI.ROFAReasonDetails.Customer,
	HI.ROFAReasonDetails.Details,
	HI.ROFAReasonDetails.PBA,
	HI.ROFAReasonDetails.pxCreateDateTime,
	HI.ROFAReasonDetails.pxCreateOperator,
	HI.ROFAReasonDetails.pxCreateOpName,
	HI.ROFAReasonDetails.pxCreateSystemID,
	HI.ROFAReasonDetails.pxObjClass,
	HI.ROFAReasonDetails.ROFAField,
	HI.ROFAReasonDetails.SubField,
	HI.ROFAReasonDetails.Telephony
  FROM DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails_stg
  LATERAL VIEW EXPLODE(ROFAReasonDetails) exploded as HI) E
  LEFT OUTER JOIN DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails T
  ON (E.pyID = T.pyID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails
	WHERE pyID IN (
	SELECT pyID
	FROM DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails_upd);

-- Inserting updates into the table
FROM DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails_upd
INSERT INTO DASD_COBL_ACQ.rbb_lbg_OB_ROFAReasonDetails PARTITION (tran_date)
SELECT
	pyID,
	cast(subscript as bigint),
	Customer,
	Details,
	PBA,
	timestamp(regexp_replace(pxCreateDateTime,'T|Z',' ')),
	pxCreateOperator,
	pxCreateOpName,
	pxCreateSystemID,
	pxObjClass,
	ROFAField,
	SubField,
	Telephony,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_OB_ROFAReasonDetails_stg;
drop table dasd_cobl_acq.rbb_lbg_OB_ROFAReasonDetails_upd;
