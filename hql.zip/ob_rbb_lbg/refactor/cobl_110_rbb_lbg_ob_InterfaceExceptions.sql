-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_stg  (
	pyID	string,
	InterfaceExceptions ARRAY<STRUCT<subscript:STRING,InterfaceExceptions:struct<
		LocalCaseID:string,
		CasepzInsKey:string,
		ConnectorName:string,
		ConnectorType:string,
		pxHistoryForReference:string,
		pxInsName:string,
		pxObjClass:string,
		pxTimeCreated:string,
		pyHTTPResponseCode:string,
		pyPerformer:string,
		pyStatusMessage:string,
		pzInsKey:string
>>>) COMMENT 'Optional Table Comment'
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
	"column.xpath.InterfaceExceptions"="/item/InterfaceExceptions"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions (
	pyID	string,
	subscript	string,
	LocalCaseID	string,
	CasepzInsKey	string,
	ConnectorName	string,
	ConnectorType	string,
	pxHistoryForReference	string,
	pxInsName	string,
	pxObjClass	string,
	pxTimeCreated	string,
	pyHTTPResponseCode	string,
	pyPerformer	string,
	pyStatusMessage	string,
	pzInsKey	string,
	bucked_column string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_upd
  AS SELECT E.*,TRAN_DATE FROM
 (SELECT pyID,
	IE.subscript,
	IE.InterfaceExceptions.LocalCaseID,
	IE.InterfaceExceptions.CasepzInsKey,
	IE.InterfaceExceptions.ConnectorName,
	IE.InterfaceExceptions.ConnectorType,
	IE.InterfaceExceptions.pxHistoryForReference,
	IE.InterfaceExceptions.pxInsName,
	IE.InterfaceExceptions.pxObjClass,
	IE.InterfaceExceptions.pxTimeCreated,
	IE.InterfaceExceptions.pyHTTPResponseCode,
	IE.InterfaceExceptions.pyPerformer,
	IE.InterfaceExceptions.pyStatusMessage,
	IE.InterfaceExceptions.pzInsKey
FROM dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_stg
LATERAL VIEW EXPLODE(InterfaceExceptions) exploded as IE) E
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions T
ON (E.pyID = T.pyID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions
	WHERE pyID IN (
	SELECT pyID
	FROM dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_upd);

-- Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions PARTITION (tran_date)
SELECT
	pyID,
	subscript,
	LocalCaseID,
	CasepzInsKey,
	ConnectorName,
	ConnectorType,
	pxHistoryForReference,
	pxInsName,
	pxObjClass,
	pxTimeCreated,
	pyHTTPResponseCode,
	pyPerformer,
	pyStatusMessage,
	pzInsKey,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_stg;
drop table dasd_cobl_acq.rbb_lbg_ob_InterfaceExceptions_upd;
