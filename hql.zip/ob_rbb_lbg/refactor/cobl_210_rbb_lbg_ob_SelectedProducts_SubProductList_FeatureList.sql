-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_stg (
	pyID	string,
	SELECTED_ALL_1 ARRAY<STRUCT<subscript:string>>,
	SELECTED_ALL_2 ARRAY<STRUCT<SelectedProducts:array<struct<
		subscript:string,SubProductList:struct<
		CaseProdGrpListID:string,
		Name:string>>>>>,
	SELECTED_ALL_3 ARRAY<STRUCT<SelectedProducts:array<struct<SubProductList:array<struct<
		subscript:string,FeatureList:struct<
		Client:string,
		DateOfBirth:string,
		kap_case_id:string,
		FeatureName:string>>>>>>>
)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
	"column.xpath.SELECTED_ALL_1"="/item/SelectedProducts",
	"column.xpath.SELECTED_ALL_2"="/item/SelectedProducts",
	"column.xpath.SELECTED_ALL_3"="/item/SelectedProducts"
) STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList (
	pyID	string,
	SelectedProducts	bigint,
	SubProductList	bigint,
	FeatureList	bigint,
	CaseProdGrpListID	string,
	Name	string,
	Client	string,
	DateOfBirth	string,
	kap_case_id	string,
	FeatureName	string,
	bucked_column string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_upd
AS SELECT S.*, T.tran_date FROM
(SELECT pyID,
	HI1.subscript as SelectedProducts,
	HI22.subscript as SubProductList,
	HI333.subscript as FeatureList,
	HI22.SubProductList.CaseProdGrpListID,
	HI22.SubProductList.Name,
	HI333.FeatureList.Client,
	HI333.FeatureList.DateOfBirth,
	HI333.FeatureList.kap_case_id,
	HI333.FeatureList.FeatureName
FROM dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_stg stg
lateral view posexplode(stg.SELECTED_ALL_1) pn1 as a1, HI1
lateral view posexplode(stg.SELECTED_ALL_2) pn2 as a2, HI2
lateral view posexplode(stg.SELECTED_ALL_3) pn3 as a3, HI3
lateral view posexplode(HI2.SelectedProducts) pn22 as a22, HI22
lateral view posexplode(HI3.SelectedProducts) pn33 as a33, HI33
lateral view posexplode(HI33.SubProductList) pn33 as a333, HI333
where HI22.subscript is not null and HI333.FeatureList is not null
and a1 == a2 and a2 == a3 and a22 == a33) S
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList T
on (S.pyID = T.pyID
and S.SelectedProducts = T.SelectedProducts
and S.SubProductList = T.SubProductList
and S.FeatureList = T.FeatureList);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList
	WHERE pyID IN (
	SELECT pyID
	FROM dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_upd);


-- Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList PARTITION (tran_date)
SELECT
	pyID,
	cast(SelectedProducts as bigint),
	cast(SubProductList as bigint),
	cast(FeatureList as bigint),
	CaseProdGrpListID,
	Name,
	Client,
	DateOfBirth,
	kap_case_id,
	FeatureName,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_stg;
drop table dasd_cobl_acq.rbb_lbg_ob_SelectedProducts_SubProductList_FeatureList_upd;

--Finished!
