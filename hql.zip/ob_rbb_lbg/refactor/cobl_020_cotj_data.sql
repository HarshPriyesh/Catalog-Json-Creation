SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.cotj_data (
	CaseID	string,
	RecordType      string,
	BranchStaffID   string,
	OriginatingSortCode     string,
--	DataRetrievedOn timestamp,
	DateOfApplication       string,
	AccountSortCode string,
	AccountNumber   bigint,
	BusinessAccountName     string,
	NCSColleagueStaffID     string,
	DateAccountOpened       string,
	bucked_column   string
)
PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');


INSERT INTO TABLE dasd_cobl_acq.cotj_data PARTITION (tran_date)
SELECT
	ob.CaseID
	,'D' AS RecordType
	,regexp_replace(ob.pxCreateOpName, '[^0-9]+', '') AS BranchStaffID
	,CASE WHEN ob.colleaguesortcode IS NULL THEN '000000' ELSE ob.colleaguesortcode END AS OriginatingSortCode
	,CAST(regexp_replace(to_date(ob.pxcreatedatetime) ,'-','') AS INT) AS DateOfApplication
	,ob.primarysortcode AS AccountSortCode
	,ob.primaryaccountnumber AS AccountNumber
	,ob.companyname AS BusinessAccountName
	,regexp_replace(ob.onboardingmanager, '[^0-9]+', '') as NCSColleagueStaffID
	,cast(regexp_replace(to_date(ob.primaryaccountopeneddate) ,'-','') AS INT) AS DateAccountOpened
	,'' AS bucked_column
	,CAST(${tempTranDate} AS INT) AS tran_date
FROM dasd_cobl_acq.rbb_lbg_ob_case AS ob
INNER JOIN dasd_cobl_acq.rbb_lbg_pf_case AS pf
ON (ob.caseID = pf.OriginatingCaseID and ob.PrimaryAccountType = pf.PrimaryAccountType)
WHERE (
	(ob.pxCreateOpName like '%/PBA')
	AND (OB.primaryaccountopeneddate IS NOT NULL)
	AND ((PF.pyResolvedTimestamp  >= CASE WHEN date_format(current_date(), 'EEEE') = 'Monday' THEN date_sub(current_date(),2) ELSE date_sub(current_date(),1) end)
		AND (PF.pyResolvedTimestamp < current_date())
		AND (PF.pyStatusWork = 'Resolved-Completed')
	)
);
