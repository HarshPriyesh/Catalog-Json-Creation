-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_stg  (
	pyID string,
	KAPS_ALL2 ARRAY<STRUCT<KAPs:struct<
		CaseKAPID:string>>>,
	KAPS_ALL array<STRUCT<KAPS:array<struct<
		subscript:string,DigitalAcceptance:struct<
		pxClientSession:string,
		pxCreateDateTime:string,
		pxObjClass:string
>>>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
--	"column.xpath.CaseKAPID"="/item/CompanyDetailsPage/Individual/KAPs/CaseKAPID/text()",
	"column.xpath.KAPS_ALL2"="/item/CompanyDetailsPage/Individual/KAPs",
	"column.xpath.KAPS_ALL"="/item/CompanyDetailsPage/Individual/KAPs"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';


--Exploding structures into records
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_upd;
CREATE TABLE DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_upd
AS SELECT E.*, T.tran_date FROM
(select pyID,
	HI2.KAPs.CaseKAPID,
	KDA.subscript,
	KDA.DigitalAcceptance.pxClientSession,
	KDA.DigitalAcceptance.pxCreateDateTime,
	KDA.DigitalAcceptance.pxObjClass
FROM DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_stg stg
lateral VIEW posexplode(stg.KAPS_ALL2) pn2 AS a2, HI2
lateral VIEW posexplode(stg.KAPS_ALL) pn1 AS a1, HI
lateral VIEW posexplode(HI.KAPs) pn3 AS a3, KDA
where KDA.subscript is not null and KDA.DigitalAcceptance is not null
and a1 == a2 ) E
LEFT OUTER JOIN DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance T
ON (E.pyID = T.pyID and E.CaseKAPID = T.CaseKAPID and E.subscript = T.subscript)
;

--Deleting existing records to be replaced by their updates
DELETE FROM DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance
	WHERE pyID IN (
	SELECT pyID
	FROM DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_upd);

-- Inserting updates into the table
FROM DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_upd
INSERT INTO DASD_COBL_ACQ.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance PARTITION (tran_date)
SELECT
	pyID,
	CaseKAPID,
	cast(subscript as bigint),
	pxClientSession,
	timestamp(regexp_replace(pxCreateDateTime,'T|Z',' ')),
	pxObjClass,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_stg;
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_DigitalAcceptance_upd;
