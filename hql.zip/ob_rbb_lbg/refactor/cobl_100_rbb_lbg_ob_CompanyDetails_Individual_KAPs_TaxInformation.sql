-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_stg (
	pyID  string,
	KAPS_ALL2 ARRAY<STRUCT<KAPs:struct<
		CaseKAPID:string>>>,
	KAPS_ALL ARRAY<STRUCT<KAPs:array<struct<
		subscript:string,TaxInformation:struct<
		pyCountry:string,
		pzIndexes:string
>>>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
	"column.xpath.KAPS_ALL2"="/item/CompanyDetailsPage/Individual/KAPs",
	"column.xpath.KAPS_ALL"="/item/CompanyDetailsPage/Individual/KAPs"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation (
	pyID  string,
	CaseKAPID	   string,
	subscript	bigint,
	pyCountry	string,
	pzIndexes	bigint,
	bucked_column string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_upd
AS SELECT E.*, T.tran_date FROM
(SELECT pyID,
	HI2.KAPs.CaseKAPID,
	KTI.subscript,
	KTI.TaxInformation.pyCountry,
	KTI.TaxInformation.pzIndexes
FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_stg stg
lateral VIEW posexplode(stg.KAPS_ALL2) pn2 AS a2, HI2
lateral VIEW posexplode(stg.KAPS_ALL) pn1 AS a1, HI
lateral VIEW posexplode(HI.KAPs) pn3 AS a3, KTI
where KTI.subscript is not null and KTI.TaxInformation is not null
and a1 == a2 ) E
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation T
ON (E.pyID = T.pyID and E.CaseKAPID = T.CaseKAPID and E.subscript = T.subscript)
;

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation
	WHERE pyID IN (
	SELECT pyID
	FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_upd);

-- Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation PARTITION (tran_date)
SELECT
	pyID,
	CaseKAPID,
	cast(subscript as bigint),
	pyCountry,
	cast(pzIndexes as bigint),
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_stg;
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_TaxInformation_upd;
