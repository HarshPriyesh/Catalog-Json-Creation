-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_stg  (
	pyID	string,
	Shareholders ARRAY<STRUCT<subscript:STRING,Shareholders:struct<
		OutstandingHitsCount:string,
		PerformAdverseMedia:string,
		PerformRiskChecks:string,
		pxCreateDateTime:string,
		pxCreateOperator:string,
		pxCreateOpName:string,
		pxCreateSystemID:string,
		pxObjClass:string,
		RiskCheckDocID:string,
		ShareholderName:string,
		ShareholderType:string,
		ShareholdingPercentage:string
>>>) COMMENT 'Optional Table Comment'
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
	"column.xpath.Shareholders"="/item/CompanyDetailsPage/Shareholders"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders (
	pyID	string,
	subscript	string,
	OutstandingHitsCount	decimal(15,5),
	PerformAdverseMedia	bigint,
	PerformRiskChecks	bigint,
	pxCreateDateTime	timestamp,
	pxCreateOperator	string,
	pxCreateOpName	string,
	pxCreateSystemID	string,
	pxObjClass	string,
	RiskCheckDocID	string,
	ShareholderName	string,
	ShareholderType	string,
	ShareholdingPercentage	string,
	bucked_column string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_upd
  AS SELECT E.*,TRAN_DATE FROM
 (SELECT pyID,
	SH.subscript,
	SH.Shareholders.OutstandingHitsCount,
	SH.Shareholders.PerformAdverseMedia,
	SH.Shareholders.PerformRiskChecks,
	SH.Shareholders.pxCreateDateTime,
	SH.Shareholders.pxCreateOperator,
	SH.Shareholders.pxCreateOpName,
	SH.Shareholders.pxCreateSystemID,
	SH.Shareholders.pxObjClass,
	SH.Shareholders.RiskCheckDocID,
	SH.Shareholders.ShareholderName,
	SH.Shareholders.ShareholderType,
	SH.Shareholders.ShareholdingPercentage
FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_stg
LATERAL VIEW EXPLODE(Shareholders) exploded as SH) E
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders T
ON (E.pyID = T.pyID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders
	WHERE pyID IN (
	SELECT pyID
	FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_upd);

-- Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders PARTITION (tran_date)
SELECT
	pyID,
	subscript,
	cast(OutstandingHitsCount as decimal(15,5)),
	cast(PerformAdverseMedia as bigint),
	cast(PerformRiskChecks as bigint),
	timestamp(regexp_replace(pxCreateDateTime,'T|Z',' ')),
	pxCreateOperator,
	pxCreateOpName,
	pxCreateSystemID,
	pxObjClass,
	RiskCheckDocID,
	ShareholderName,
	ShareholderType,
	ShareholdingPercentage,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_stg;
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Shareholders_upd;
