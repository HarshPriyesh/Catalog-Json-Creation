-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions_stg  (
	pyID	string,
	HistoricalInteractions ARRAY<STRUCT<subscript:STRING,HistoricalInteractions:struct<
	CommunicationMethod:string,
	ContactName:string,
	DateAndTime:string,
	Details:string,
	InteractionPurpose:string,
	InternalContactName:string,
	PartyContacted:string,
	pxObjClass:string
>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
	"column.xpath.HistoricalInteractions"="/item/HistoricalInteractions"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions (
	pyID	string,
	subscript bigint,
	CommunicationMethod string,
	ContactName string,
	DateAndTime timestamp,
	Details string,
	InteractionPurpose string,
	InternalContactName string,
	PartyContacted string,
	pxObjClass string,
	bucked_column string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');

--Exploding structures into records
DROP TABLE IF EXISTS DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions_upd;
CREATE TABLE DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions_upd
  AS SELECT E.*,TRAN_DATE FROM
 (SELECT pyID,
  HI.subscript,
  HI.HistoricalInteractions.CommunicationMethod,
  HI.HistoricalInteractions.ContactName,
  HI.HistoricalInteractions.DateAndTime,
  HI.HistoricalInteractions.Details,
  HI.HistoricalInteractions.InteractionPurpose,
  HI.HistoricalInteractions.InternalContactName,
  HI.HistoricalInteractions.PartyContacted,
  HI.HistoricalInteractions.pxObjClass
  FROM DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions_stg
  LATERAL VIEW EXPLODE(HistoricalInteractions) exploded as HI) E
  LEFT OUTER JOIN DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions T
  ON (E.pyID = T.pyID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions
	WHERE pyID IN (
	SELECT pyID
	FROM DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions_upd);

-- Inserting updates into the table
FROM DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions_upd
INSERT INTO DASD_COBL_ACQ.rbb_lbg_OB_HistoricalInteractions PARTITION (tran_date)
SELECT
	pyID,
	cast(subscript as bigint),
	CommunicationMethod,
	ContactName,
	timestamp(regexp_replace(DateAndTime,'T|Z',' ')),
	Details,
	InteractionPurpose,
	InternalContactName,
	PartyContacted,
	pxObjClass,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_OB_HistoricalInteractions_stg;
drop table dasd_cobl_acq.rbb_lbg_OB_HistoricalInteractions_upd;
