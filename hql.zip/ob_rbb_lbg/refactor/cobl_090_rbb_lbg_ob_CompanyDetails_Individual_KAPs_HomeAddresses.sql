-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_stg  (
	pyID string,
	KAPS_ALL2 ARRAY<STRUCT<KAPs:struct<
		CaseKAPID:string>>>,
	KAPS_ALL array<STRUCT<KAPS:array<struct<
		subscript:string,HomeAddresses:struct<
		AddressLineOne:string,
		AddressLineTwo:string,
		pyCity:string,
		AddressLineFour:string,
		PostCode:string,
		pyCountry:string,
		UseAddressSearch:string,
		MonthWhenMovedToTheAddress:string,
		YearWhenMovedToTheAddress:string,
		StayingCurrentlyAtThisAddress:string,
		MonthsStayedAtTheAddress:string,
		YearsStayedAtTheAddress:string,
		TotalMonthsStayedAtTheAddress:string
>>>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.pyID"="/item/pyID/text()",
	"column.xpath.KAPS_ALL2"="/item/CompanyDetailsPage/Individual/KAPs",
	"column.xpath.KAPS_ALL"="/item/CompanyDetailsPage/Individual/KAPs"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}'
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx6400m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses (
	pyID	string,
	CaseKAPID	string,
	subscript	bigint,
	AddressLineOne	string,
	AddressLineTwo	string,
	pyCity	string,
	AddressLineFour	string,
	PostCode	string,
	pyCountry	string,
	UseAddressSearch	string,
	MonthWhenMovedToTheAddress	bigint,
	YearWhenMovedToTheAddress	bigint,
	StayingCurrentlyAtThisAddress	string,
	MonthsStayedAtTheAddress	bigint,
	YearsStayedAtTheAddress	bigint,
	TotalMonthsStayedAtTheAddress	bigint,
	bucked_column string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_upd
AS SELECT E.*, T.tran_date FROM
(select pyID,
	HI2.KAPs.CaseKAPID,
	KDA.subscript,
	KDA.HomeAddresses.AddressLineOne,
	KDA.HomeAddresses.AddressLineTwo,
	KDA.HomeAddresses.pyCity,
	KDA.HomeAddresses.AddressLineFour,
	KDA.HomeAddresses.PostCode,
	KDA.HomeAddresses.pyCountry,
	KDA.HomeAddresses.UseAddressSearch,
	KDA.HomeAddresses.MonthWhenMovedToTheAddress,
	KDA.HomeAddresses.YearWhenMovedToTheAddress,
	KDA.HomeAddresses.StayingCurrentlyAtThisAddress,
	KDA.HomeAddresses.MonthsStayedAtTheAddress,
	KDA.HomeAddresses.YearsStayedAtTheAddress,
	KDA.HomeAddresses.TotalMonthsStayedAtTheAddress
FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_stg stg
lateral VIEW posexplode(stg.KAPS_ALL2) pn2 AS a2, HI2
lateral VIEW posexplode(stg.KAPS_ALL) pn1 AS a1, HI
lateral VIEW posexplode(HI.KAPs) pn3 AS a3, KDA
where KDA.subscript is not null and KDA.HomeAddresses is not null
and a2 == a1) E
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses T
ON (E.pyID = T.pyID and E.CaseKAPID = T.CaseKAPID and E.subscript = T.subscript)
;

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses
	WHERE pyID IN (
	SELECT pyID
	FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_upd);

-- Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses PARTITION (tran_date)
SELECT
	pyID,
	CaseKAPID,
	cast(subscript as bigint),
	AddressLineOne,
	AddressLineTwo,
	pyCity,
	AddressLineFour,
	PostCode,
	pyCountry,
	UseAddressSearch,
	cast(MonthWhenMovedToTheAddress as bigint),
	cast(YearWhenMovedToTheAddress as bigint),
	StayingCurrentlyAtThisAddress,
	cast(MonthsStayedAtTheAddress as bigint),
	cast(YearsStayedAtTheAddress as bigint),
	cast(TotalMonthsStayedAtTheAddress as bigint),
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_stg;
drop table dasd_cobl_acq.rbb_lbg_ob_CompanyDetails_Individual_KAPs_HomeAddresses_upd;
