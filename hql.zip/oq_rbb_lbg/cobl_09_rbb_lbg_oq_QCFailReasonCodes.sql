-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_stg  (
	CaseID	string,
	QC_FAIL ARRAY<STRUCT<subscript:STRING,QCFailReasonCodes:struct<
	AppealDate:string,
	AppealAction:string,
	AppealActionDate:string,
	AppealReason:string,
	Details:string,
	FailHousekeeping:string,
	FailPolicy:string,
	FailureType:string,
	Identifier:string,
	IsAppealed:string,
	pxCreateDateTime:string,
	pxCreateOperator:string,
	pxCreateOpName:string,
	pxCreateSystemID:string,
	pxObjClass:string,
	pyExpanded:string,
	pzIndexes:string,
	ReasonCode:string,
	ReasonCodeSubCategory:string
>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.CaseID"="/item/pyID/text()",
	"column.xpath.QC_FAIL"="/item/QCFailReasonCodes"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat' 
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' 
LOCATION '${xmlSourcePath}' 
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes (
	CaseID	string,
	subscript	bigint,
	AppealDate	timestamp,
	AppealAction	string,
	AppealActionDate	timestamp,
	AppealReason	string,
	Details	string,
	FailHousekeeping	string,
	FailPolicy	string,
	FailureType	string,
	Identifier	string,
	IsAppealed	string,
	pxCreateDateTime	timestamp,
	pxCreateOperator	string,
	pxCreateOpName	string,
	pxCreateSystemID	string,
	pxObjClass	string,
	pyExpanded	string,
	pzIndexes	string,
	ReasonCode	string,
	ReasonCodeSubCategory	string,
	bucked_column	string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd 
AS SELECT E.*,TRAN_DATE FROM 
(SELECT CaseID,
	QCF.subscript,
	QCF.QCFailReasonCodes.AppealDate,
	QCF.QCFailReasonCodes.AppealAction,
	QCF.QCFailReasonCodes.AppealActionDate,
	QCF.QCFailReasonCodes.AppealReason,
	QCF.QCFailReasonCodes.Details,
	QCF.QCFailReasonCodes.FailHousekeeping,
	QCF.QCFailReasonCodes.FailPolicy,
	QCF.QCFailReasonCodes.FailureType,
	QCF.QCFailReasonCodes.Identifier,
	QCF.QCFailReasonCodes.IsAppealed,
	QCF.QCFailReasonCodes.pxCreateDateTime,
	QCF.QCFailReasonCodes.pxCreateOperator,
	QCF.QCFailReasonCodes.pxCreateOpName,
	QCF.QCFailReasonCodes.pxCreateSystemID,
	QCF.QCFailReasonCodes.pxObjClass,
	QCF.QCFailReasonCodes.pyExpanded,
	QCF.QCFailReasonCodes.pzIndexes,
	QCF.QCFailReasonCodes.ReasonCode,
	QCF.QCFailReasonCodes.ReasonCodeSubCategory
FROM dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_stg 
LATERAL VIEW EXPLODE(QC_FAIL) exploded as QCF) E 
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes T 
ON (E.CaseID = T.CaseID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes 
	WHERE CaseID IN (
	SELECT CaseID 
	FROM dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes PARTITION (tran_date)
SELECT
	CaseID,
	cast(subscript as bigint),
	timestamp(regexp_replace(AppealDate,'T|Z',' ')),
	AppealAction,
	timestamp(regexp_replace(AppealActionDate,'T|Z',' ')),
	AppealReason,
	Details,
	FailHousekeeping,
	FailPolicy,
	FailureType,
	Identifier,
	IsAppealed,
	timestamp(regexp_replace(pxCreateDateTime,'T|Z',' ')),
	pxCreateOperator,
	pxCreateOpName,
	pxCreateSystemID,
	pxObjClass,
	pyExpanded,
	pzIndexes,
	ReasonCode,
	ReasonCodeSubCategory,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_QCFailReasonCodes_upd;