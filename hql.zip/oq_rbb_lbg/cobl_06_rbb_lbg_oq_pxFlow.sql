-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_pxFlow_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_pxFlow_stg (
	CaseID	string,
	PX_FLOW ARRAY<STRUCT<subscript:STRING,pxFlow:struct<
	pxAssignActivity:string,
	pxAssignClass:string,
	pxAssignDeadTime:string,
	pxAssignGoalTime:string,
	pxAssignmentKey:string,
	pxAssignSvcLevel:string,
	pxFlowInsKey:string,
	pxIsInvestigative:string,
	pxLastActivityStatus:string,
	pxLastUpdateBy:string,
	pxObjClass:string,
	pxRouteTo:string,
	pxRouteToUserName:string,
	pxStageFlowID:string,
	pxSystemFlow:string,
	pxTimeFlowStarted:string,
	pyActiveFlowAtStart:string,
	pyCategory:string,
	pyConfirmationNote:string,
	pyDeferCommit:string,
	pyDeferErrors:string,
	pyDraftMode:string,
	pyFirstRun:string,
	pyFlowCalledCount:string,
	pyFlowInterestPageClass:string,
	pyFlowType:string,
	pyInstructions:string,
	pyIssuedFromClass:string,
	pyIssuedFromFlow:string,
	pyIssuedFromObject:string,
	pyIssuedFromPage:string,
	pyIssuedFromStage:string,
	pyIssuedFromStageLabel:string,
	pyIssuedFromStageSubscript:string,
	pyIssuedFromTask:string,
	pyLastFlowStep:string,
	pyLastFlowStepLabel:string,
	pyParentFlowPath:string,
	pySaveCompletedFlowPath:string,
	pyTopLevelFlow:string
>>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.CaseID"="/item/pyID/text()",
	"column.xpath.PX_FLOW"="/item/pxFlow"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat' 
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' 
LOCATION '${xmlSourcePath}' 
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_pxFlow (
	CaseID	string,
	subscript	string,
	pxAssignActivity	string,
	pxAssignClass	string,
	pxAssignDeadTime	string,
	pxAssignGoalTime	string,
	pxAssignmentKey	string,
	pxAssignSvcLevel	string,
	pxFlowInsKey	string,
	pxIsInvestigative	string,
	pxLastActivityStatus	string,
	pxLastUpdateBy	string,
	pxObjClass	string,
	pxRouteTo	string,
	pxRouteToUserName	string,
	pxStageFlowID	string,
	pxSystemFlow	string,
	pxTimeFlowStarted	string,
	pyActiveFlowAtStart	string,
	pyCategory	string,
	pyConfirmationNote	string,
	pyDeferCommit	string,
	pyDeferErrors	string,
	pyDraftMode	string,
	pyFirstRun	string,
	pyFlowCalledCount	bigint,
	pyFlowInterestPageClass	string,
	pyFlowType	string,
	pyInstructions	string,
	pyIssuedFromClass	string,
	pyIssuedFromFlow	string,
	pyIssuedFromObject	string,
	pyIssuedFromPage	string,
	pyIssuedFromStage	string,
	pyIssuedFromStageLabel	string,
	pyIssuedFromStageSubscript	string,
	pyIssuedFromTask	string,
	pyLastFlowStep	string,
	pyLastFlowStepLabel	string,
	pyParentFlowPath	string,
	pySaveCompletedFlowPath	string,
	pyTopLevelFlow	string,
	bucked_column string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_pxFlow_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_pxFlow_upd 
AS SELECT E.*,TRAN_DATE FROM 
(SELECT CaseID,
	PXF.subscript,
	PXF.pxFlow.pxAssignActivity,
	PXF.pxFlow.pxAssignClass,
	PXF.pxFlow.pxAssignDeadTime,
	PXF.pxFlow.pxAssignGoalTime,
	PXF.pxFlow.pxAssignmentKey,
	PXF.pxFlow.pxAssignSvcLevel,
	PXF.pxFlow.pxFlowInsKey,
	PXF.pxFlow.pxIsInvestigative,
	PXF.pxFlow.pxLastActivityStatus,
	PXF.pxFlow.pxLastUpdateBy,
	PXF.pxFlow.pxObjClass,
	PXF.pxFlow.pxRouteTo,
	PXF.pxFlow.pxRouteToUserName,
	PXF.pxFlow.pxStageFlowID,
	PXF.pxFlow.pxSystemFlow,
	PXF.pxFlow.pxTimeFlowStarted,
	PXF.pxFlow.pyActiveFlowAtStart,
	PXF.pxFlow.pyCategory,
	PXF.pxFlow.pyConfirmationNote,
	PXF.pxFlow.pyDeferCommit,
	PXF.pxFlow.pyDeferErrors,
	PXF.pxFlow.pyDraftMode,
	PXF.pxFlow.pyFirstRun,
	PXF.pxFlow.pyFlowCalledCount,
	PXF.pxFlow.pyFlowInterestPageClass,
	PXF.pxFlow.pyFlowType,
	PXF.pxFlow.pyInstructions,
	PXF.pxFlow.pyIssuedFromClass,
	PXF.pxFlow.pyIssuedFromFlow,
	PXF.pxFlow.pyIssuedFromObject,
	PXF.pxFlow.pyIssuedFromPage,
	PXF.pxFlow.pyIssuedFromStage,
	PXF.pxFlow.pyIssuedFromStageLabel,
	PXF.pxFlow.pyIssuedFromStageSubscript,
	PXF.pxFlow.pyIssuedFromTask,
	PXF.pxFlow.pyLastFlowStep,
	PXF.pxFlow.pyLastFlowStepLabel,
	PXF.pxFlow.pyParentFlowPath,
	PXF.pxFlow.pySaveCompletedFlowPath,
	PXF.pxFlow.pyTopLevelFlow
FROM dasd_cobl_acq.rbb_lbg_oq_pxFlow_stg 
LATERAL VIEW EXPLODE(PX_FLOW) exploded as PXF) E 
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_pxFlow T 
ON (E.CaseID = T.CaseID and E.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_pxFlow 
	WHERE CaseID IN (
	SELECT CaseID 
	FROM dasd_cobl_acq.rbb_lbg_oq_pxFlow_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_pxFlow_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_pxFlow PARTITION (tran_date)
SELECT
	CaseID,
	subscript,
	pxAssignActivity,
	pxAssignClass,
	pxAssignDeadTime,
	pxAssignGoalTime,
	pxAssignmentKey,
	pxAssignSvcLevel,
	pxFlowInsKey,
	pxIsInvestigative,
	pxLastActivityStatus,
	pxLastUpdateBy,
	pxObjClass,
	pxRouteTo,
	pxRouteToUserName,
	pxStageFlowID,
	pxSystemFlow,
	pxTimeFlowStarted,
	pyActiveFlowAtStart,
	pyCategory,
	pyConfirmationNote,
	pyDeferCommit,
	pyDeferErrors,
	pyDraftMode,
	pyFirstRun,
	cast(pyFlowCalledCount as bigint),
	pyFlowInterestPageClass,
	pyFlowType,
	pyInstructions,
	pyIssuedFromClass,
	pyIssuedFromFlow,
	pyIssuedFromObject,
	pyIssuedFromPage,
	pyIssuedFromStage,
	pyIssuedFromStageLabel,
	pyIssuedFromStageSubscript,
	pyIssuedFromTask,
	pyLastFlowStep,
	pyLastFlowStepLabel,
	pyParentFlowPath,
	pySaveCompletedFlowPath,
	pyTopLevelFlow,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_pxFlow_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_pxFlow_upd;