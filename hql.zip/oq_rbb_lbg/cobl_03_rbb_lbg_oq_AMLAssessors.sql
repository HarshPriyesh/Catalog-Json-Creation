-- Reading XML files into Hive Structures
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_stg  (
	CaseID	string,
	AML_ASSESSORS ARRAY<STRUCT<subscript:string,
		AMLAssessors:string
>>)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.CaseID"="/item/pyID/text()",
	"column.xpath.AML_ASSESSORS"="/item/AMLAssessors"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat' 
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat' 
LOCATION '${xmlSourcePath}' 
TBLPROPERTIES ("xmlinput.start"="<item id=","xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_AMLAssessors (
	CaseID string,
	subscript bigint,
	AMLAssessors string,
	bucked_column string
) PARTITIONED BY (tran_date string) 
CLUSTERED BY (bucked_column) into 32 BUCKETS 
STORED AS ORC TBLPROPERTIES('transactional'='true'); 

--Exploding structures into records
DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd 
AS SELECT S.*, T.tran_date FROM 
(SELECT CaseID,
	AA.subscript,
	AA.AMLAssessors
FROM dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_stg 
LATERAL VIEW EXPLODE(AML_ASSESSORS) exploded as AA) S
LEFT OUTER JOIN dasd_cobl_acq.rbb_lbg_oq_AMLAssessors T 
ON (S.CaseID = T.CaseID and S.subscript = T.subscript);

--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_AMLAssessors WHERE CaseID IN (
	SELECT CaseID 
	FROM dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd);

--Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_AMLAssessors PARTITION (tran_date)
SELECT
	CaseID,
	cast(subscript as bigint),
	AMLAssessors,
	'' as bucked_column,
	CAST(${tempTranDate} AS INT) as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_AMLAssessors_upd;