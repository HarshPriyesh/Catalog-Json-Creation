DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_xml_stg;

add jar hdfs://PRODHDPL01HA:8020/HADOOP/DASD_ACQ/common/cobl/lib/hivexmlserde-1.0.5.3.jar;
CREATE EXTERNAL TABLE dasd_cobl_acq.rbb_lbg_oq_xml_stg (
	CaseID  string,
	pxUpdateDateTime	string,
	pxCreateDateTime	string,
	XML_ITEM ARRAY<string>
)
ROW FORMAT SERDE 'com.ibm.spss.hive.serde2.xml.XmlSerDe' WITH SERDEPROPERTIES (
	"column.xpath.CaseID"="/item/pyID/text()",
	"column.xpath.pxUpdateDateTime"="/item/pxUpdateDateTime/text()",
	"column.xpath.pxCreateDateTime"="/item/pxCreateDateTime/text()",
	"column.xpath.XML_ITEM"="/item"
)
STORED AS INPUTFORMAT 'com.ibm.spss.hive.serde2.xml.XmlInputFormat'
OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.HiveIgnoreKeyTextOutputFormat'
LOCATION '${xmlSourcePath}' 
TBLPROPERTIES ("xmlinput.start"="<item id",
		"xmlinput.end"="</item>");

SET mapreduce.job.queuename=${queueName};
SET hive.execution.engine=tez;
SET hive.enforce.bucketing=true;
SET tez.queue.name=${queueName};
SET hive.tez.container.size=8192;
SET hive.tez.java.opts='-Xmx4000m';

CREATE TABLE IF NOT EXISTS dasd_cobl_acq.rbb_lbg_oq_xml (
	CaseID  string,
	pxUpdateDateTime	string,
	pxCreateDateTime	string,
	XML_ITEM	string,
	bucked_column   string
) PARTITIONED BY (tran_date string)
CLUSTERED BY (bucked_column) into 32 BUCKETS
STORED AS ORC TBLPROPERTIES('transactional'='true');


DROP TABLE IF EXISTS dasd_cobl_acq.rbb_lbg_oq_xml_upd;
CREATE TABLE dasd_cobl_acq.rbb_lbg_oq_xml_upd
AS SELECT *
FROM dasd_cobl_acq.rbb_lbg_oq_xml_stg
;


--Deleting existing records to be replaced by their updates
DELETE FROM dasd_cobl_acq.rbb_lbg_oq_xml WHERE CaseID IN(
	SELECT CaseID
	FROM dasd_cobl_acq.rbb_lbg_oq_xml_upd);

-- Inserting updates into the table
FROM dasd_cobl_acq.rbb_lbg_oq_xml_upd
INSERT INTO dasd_cobl_acq.rbb_lbg_oq_xml PARTITION (tran_date)
SELECT
	CaseID,
	pxUpdateDateTime,
	pxCreateDateTime,
	cast(XML_ITEM[0] as string),
	'' as bucked_column,
	${tempTranDate} as tran_date;

-- Dropping intermediate tables
drop table dasd_cobl_acq.rbb_lbg_oq_xml_stg;
drop table dasd_cobl_acq.rbb_lbg_oq_xml_upd;